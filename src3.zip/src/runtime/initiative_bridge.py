"""
InitiativeBridge —— 将 initiative_sender 注册为 Runtime ActionDispatcher 的处理器

设计原则：
- 保留现有 initiative_sender.py 逻辑，不重写
- 只是适配 Action -> initiative_sender 函数调用
- 可回滚：移除 bridge 不影响 initiative_sender 独立运行
"""

import logging
from typing import Any, Dict, Optional

from src.runtime.action_dispatcher import Action
from src.runtime.runtime_bridge import get_runtime_bridge

logger = logging.getLogger(__name__)


class InitiativeBridge:
    """
    initiative_sender 适配桥

    负责将 RuntimeCore 的 send_message 决策，
    适配到现有的 initiative_sender 发送函数。

    分两级：
    1. RuntimeCore 内：通过 runtime_bridge.register_action_handler("send_message", handler)
       将 handler 注册到 ActionDispatcher
    2. handler 内：通过发送方接口实际发送
    """

    def __init__(self, orchestrator: Any = None, send_config: Optional[Dict[str, Any]] = None):
        self._orchestrator = orchestrator
        self._send_config = send_config or {}
        self._registered = False

    # ==================== Action Handler ====================

    def handle_send_message(self, action: Action) -> Dict[str, Any]:
        """
        ActionDispatcher 回调：处理 send_message 行动

        Args:
            action: Action 对象，payload 中可能包含:
                - type: 行动类型（proactive / greeting / etc.）
                - context: 上下文描述
                - message: 可选，预先生成的消息

        Returns:
            发送结果字典
        """
        payload = action.payload or {}
        result = {
            "action_id": action.action_id,
            "action_type": action.action_type,
            "sent": False,
            "message": None,
            "reason": action.reason,
        }

        # 方式一：payload 中已有预生成消息
        message = payload.get("message")

        # 方式二：使用 Orchestrator.generate_initiative() 生成消息
        if not message and self._orchestrator:
            try:
                target_user = self._send_config.get(
                    "target_user",
                    getattr(self._orchestrator, "target_user_id", None),
                )
                if target_user:
                    message = self._orchestrator.generate_initiative(target_user)
            except Exception as e:
                logger.exception(f"InitiativeBridge: 生成主动消息失败: {e}")
                result["error"] = f"generate_initiative failed: {e}"

        if not message:
            result["message"] = None
            result["reason"] = "no message generated; skipped"
            return result

        result["message"] = message

        # 尝试发送
        sent = self._send_message(message)
        result["sent"] = sent

        # 通知 RuntimeCore：主动行为已执行（触发 SelfState 更新）
        try:
            bridge = get_runtime_bridge()
            core = bridge.get_runtime_core()
            if core:
                core.inject_event(
                    "action.proactive_executed",
                    {
                        "action_id": action.action_id,
                        "action_content": message,
                        "user_response": None,
                    },
                )
        except Exception:
            pass

        logger.info(
            f"InitiativeBridge: send_message {action.action_id} "
            f"sent={sent} message={message[:60]!r}"
        )
        return result

    # ==================== 发送实现 ====================

    def _send_message(self, message: str) -> bool:
        """
        实际发送消息（兼容两种模式）

        模式 A：有 config（api_type/onebot_url/target_user 等）→ 直接调用
        模式 B：只有 callback → 调用外部回调
        模式 C：都没有 → 记录日志，不实际发送
        """
        # 模式 B：回调优先
        callback = self._send_config.get("send_callback")
        if callback:
            try:
                result = callback(message)
                return bool(result)
            except Exception as e:
                logger.exception(f"InitiativeBridge: send_callback 异常: {e}")
                return False

        # 模式 A：直接调用 initiative_sender 函数
        cfg = self._send_config
        api_type = cfg.get("api_type", "onebot")
        target_user = cfg.get("target_user")
        if not target_user:
            logger.warning("InitiativeBridge: 未配置 target_user，跳过发送")
            return False

        try:
            from initiative_sender import send_private_msg_onebot, send_private_msg_astrbot

            if api_type == "onebot":
                api_url = cfg.get("onebot_url")
                token = cfg.get("onebot_token", "")
                timeout = cfg.get("request_timeout", 8.0)
                return send_private_msg_onebot(api_url, target_user, message, timeout, token)
            else:
                api_url = cfg.get("astrbot_url")
                timeout = cfg.get("request_timeout", 8.0)
                return send_private_msg_astrbot(api_url, target_user, message, timeout)
        except Exception as e:
            logger.exception(f"InitiativeBridge: 发送消息异常: {e}")
            return False

    # ==================== 注册 ====================

    def register(self) -> bool:
        """
        将 handle_send_message 注册到 RuntimeCore 的 ActionDispatcher

        Returns:
            是否注册成功
        """
        if self._registered:
            return True
        try:
            bridge = get_runtime_bridge()
            bridge.register_action_handler("send_message", self.handle_send_message)
            bridge.mark_action_handlers_ready()
            self._registered = True
            logger.info("InitiativeBridge: send_message handler 已注册")
            return True
        except Exception as e:
            logger.exception(f"InitiativeBridge: 注册处理器失败: {e}")
            return False

    @property
    def is_registered(self) -> bool:
        return self._registered