# -*- coding: utf-8 -*-
"""
src/runtime/adapters/impl/response_adapter_impl.py

Phase 3.8.4: ResponseAdapterImpl —— ResponseEngine 桥接

职责:
- 在 Runtime RESPONSE_GENERATION 阶段,接受 ResponseAdapter 产出的 ResponseRequest,
  调用 ResponseEngine.generate(...) 生成 LLM 回复,
  并把回复回填到 ctx,供 Guard Chain 审计。

设计:
- 不持有 openai 客户端
- 不修改 ResponseEngine / LLMClient / PromptBuilder
- 失败隔离:任何异常都会被 Runtime 捕获,不中断整个 process()

注意:
- ResponseEngine 可能在没有 DEEPSEEK_API_KEY 的环境抛错,
  Impl 应捕获并返回 fallback 文本。
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from src.runtime.adapters.base import AdapterBase
from src.runtime.adapters.response_adapter import (
    ResponseAdapter,
    ResponseRequest,
    RESPONSE_ADAPTER_SCHEMA_VERSION,
)

logger = logging.getLogger(__name__)


class ResponseAdapterImpl(ResponseAdapter):
    """ResponseEngine 桥接实现（Phase 3.8.4 / v1.0）。

    使用方式:
        impl = ResponseAdapterImpl()
        impl.attach()
        req = impl.build_request(ctx, prc, event)
        reply = impl.generate(req)
    """

    name: str = "response_adapter_impl"
    schema_version: str = RESPONSE_ADAPTER_SCHEMA_VERSION

    def __init__(
        self,
        response_engine: Optional[Any] = None,
        fallback_reply: str = "（回复生成暂不可用）",
        self_model_context_provider: Optional[Any] = None,
        self_reflection_context_provider: Optional[Any] = None,
        identity_context_provider: Optional[Any] = None,
        personality_binding_provider: Optional[Any] = None,
    ) -> None:
        super().__init__(
            self_model_context_provider=self_model_context_provider,
            self_reflection_context_provider=self_reflection_context_provider,
            identity_context_provider=identity_context_provider,
            personality_binding_provider=personality_binding_provider,
        )
        self._response_engine = response_engine
        self._fallback_reply = fallback_reply
        self._last_reply: Optional[str] = None
        self._generate_count: int = 0

    # --------------------------------------------------------
    # AdapterBase 生命周期
    # --------------------------------------------------------
    def attach(self) -> None:
        """注入 ResponseEngine（默认延迟加载,失败不影响 Runtime 启动）。"""
        if self._response_engine is None:
            try:
                # 仅在 attach 时尝试 import,避免循环依赖
                from src.response.engine import ResponseEngine
                self._response_engine = ResponseEngine()
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "ResponseAdapterImpl.attach() 加载 ResponseEngine 失败: %s", exc
                )
                self._response_engine = None
        self._mark_attached()
        self._cache_health({
            "healthy": True,
            "name": self.name,
            "schema_version": self.schema_version,
            "engine_loaded": self._response_engine is not None,
        })

    def detach(self) -> None:
        self._response_engine = None
        self._last_reply = None
        self._mark_detached()

    def health_check(self) -> Dict[str, Any]:
        result = {
            "healthy": self.is_attached,
            "name": self.name,
            "schema_version": self.schema_version,
            "engine_loaded": self._response_engine is not None,
        }
        self._cache_health(result)
        return result

    # --------------------------------------------------------
    # 业务接口
    # --------------------------------------------------------
    def generate(self, request: ResponseRequest) -> str:
        """调用 ResponseEngine.generate(...) 返回回复。

        失败时返回 self._fallback_reply,不抛异常（保证 Runtime 阶段不中断）。
        """
        if not self.is_attached:
            return self._fallback_reply

        if self._response_engine is None:
            return self._fallback_reply

        try:
            # 翻译 ResponseRequest → ResponseEngine.generate 参数
            personality_context = request.personality_context or {}
            # 兼容 personality_text 形式
            if "personality_text" not in personality_context:
                cs = personality_context.get("communication_style") or {}
                if cs:
                    style = " ".join(f"{k}={v}" for k, v in cs.items())
                    personality_context["personality_text"] = (
                        f"【表达风格】{style}"
                    )
            # Phase 4.2.3: 保留 SelfModel 注入(self_model_text / self_model_data)
            # 不修改 ResponseEngine.generate(),通过 personality_context 透传
            reply = self._response_engine.generate(
                user_message=request.user_input or "",
                history=[],
                chat_memories=[],
                life_events=[],
                personality_context=personality_context,
                resolved_behavior=None,
                expression_constraint_text=None,
            )
            self._last_reply = reply
            self._generate_count += 1
            return reply
        except Exception as exc:  # noqa: BLE001
            logger.warning("ResponseAdapterImpl.generate 失败: %s", exc)
            self._last_reply = self._fallback_reply
            return self._fallback_reply

    @property
    def last_reply(self) -> Optional[str]:
        return self._last_reply

    @property
    def generate_count(self) -> int:
        return self._generate_count


__all__ = ["ResponseAdapterImpl"]
