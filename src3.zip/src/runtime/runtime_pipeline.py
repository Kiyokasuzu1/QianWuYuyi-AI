# -*- coding: utf-8 -*-
"""
src/runtime/runtime_pipeline.py

Phase 6.3 —— Runtime Orchestration Integration(编排层)。

职责:
    提供一次完整运行入口 ``RuntimePipeline.run(input_data)``,
    把"用户输入 → RuntimeContext → Orchestrator → 收集结果 → 持久化 → 事件"
    串成一条可执行链路。

设计原则:
    1. Pipeline 是**编排层**,不实现任何业务逻辑(不复制 Memory/Emotion/
       Growth/Personality/Response 的实现)。
    2. Orchestrator / persistence_hook / event_sink / token_optimizer
       全部**构造注入**,便于测试替换为 fake。
    3. 任意模块失败都被隔离,Pipeline 总能返回 RuntimeContext(failed 终态)。
    4. 不修改 Authority(Memory/Emotion/Growth/Personality/...) 内部代码。
    5. 不调用 LLM、不引入新事件系统、不引入新数据库。

依赖:
    - stdlib (logging, threading, time, uuid)
    - RuntimeContext (Phase 6.0,仅 import)
    - RuntimePersistenceHook (Phase 6.2,可选)
    - RuntimeTokenOptimizer / NoOpTokenOptimizer (Phase 6.5,可选)
    - 业务模块:Orchestrator(仅通过 OrchestratorLike 协议使用)
"""
from __future__ import annotations

import logging
import threading
import time
import uuid
from typing import TYPE_CHECKING, Any, Dict, Optional, Protocol

if TYPE_CHECKING:  # pragma: no cover
    from src.runtime.lifecycle_context import RuntimeContext

logger = logging.getLogger(__name__)


# ============================================================
# Schema 版本常量
# ============================================================
RUNTIME_PIPELINE_SCHEMA_VERSION = "1.0"


# ============================================================
# 协议(允许测试 fake)
# ============================================================
class OrchestratorLike(Protocol):
    """Pipeline 所需的最小 Orchestrator 接口(Protocol)。

    任何实现 ``process(user_message: str) -> str`` 的对象都可注入。
    src.orchestrator.Orchestrator 满足此协议(且 process() 内部已做
    异常隔离,返回字符串或兜底文本)。
    """

    def process(self, user_message: str) -> str:  # pragma: no cover
        ...


class EventSinkLike(Protocol):
    """可选事件 sink 协议。

    Pipeline 在终态后调用 ``sink.emit(event_dict)`` 写入事件流。
    任何实现 ``emit(event: Dict) -> None`` 的对象都可注入。
    sink=None 表示无事件发布(纯运行,不写事件)。
    """

    def emit(self, event: Dict[str, Any]) -> None:  # pragma: no cover
        ...


class TokenOptimizerLike(Protocol):
    """Phase 6.5 —— 可选 Token 优化器协议。

    Pipeline 在 user_message 进入 Orchestrator 之前调用
    ``optimizer.optimize(user_message, history, memories)``,
    返回 dict(至少含 ``content`` 字段)。
    optimizer=None 时 Pipeline 跳过优化,行为与 Phase 6.3 完全一致。
    """

    def optimize(  # pragma: no cover
        self,
        user_message: str,
        history: Optional[Any] = None,
        memories: Optional[Any] = None,
    ) -> Dict[str, Any]:
        ...


# ============================================================
# 异常
# ============================================================
class RuntimePipelineError(Exception):
    """Pipeline 错误基类。"""


# ============================================================
# 主类
# ============================================================
class RuntimePipeline:
    """Runtime 编排入口。

    典型用法:
        from src.orchestrator import Orchestrator
        from src.runtime.context_storage import RuntimeContextStorage
        from src.runtime.lifecycle.persistence_hook import RuntimePersistenceHook
        from src.runtime.runtime_pipeline import RuntimePipeline

        orch = Orchestrator()
        storage = RuntimeContextStorage()
        hook = RuntimePersistenceHook(storage)

        pipeline = RuntimePipeline(orchestrator=orch, persistence_hook=hook)
        ctx = pipeline.run({"user_message": "你好"})

    失败隔离:
        Orchestrator 抛错 -> context 进入 failed 终态,仍返回。
        persistence_hook 抛错 -> 已隔离,不影响主流程。
        event_sink 抛错 -> 已隔离,不影响主流程。
    """

    def __init__(
        self,
        orchestrator: Any,
        *,
        persistence_hook: Optional[Any] = None,
        event_sink: Optional[Any] = None,
        lifecycle_name: str = "runtime_pipeline",
        token_optimizer: Optional[Any] = None,
    ) -> None:
        """构造 Pipeline。

        Args:
            orchestrator: 实现 ``process(user_message: str) -> str`` 的对象。
            persistence_hook: 可选 RuntimePersistenceHook(Phase 6.2)。
            event_sink: 可选事件 sink,emit(event: dict) -> None。
            lifecycle_name: 写入 context.outputs.lifecycle.name。
            token_optimizer: 可选 Token 优化器(Phase 6.5)。
                任何实现 ``optimize(user_message, history, memories) -> dict``
                的对象即可。None 表示不启用,行为与 Phase 6.3 完全一致。
        """
        if orchestrator is None:
            raise RuntimePipelineError("orchestrator 不能为 None")
        # 校验最小接口
        if not callable(getattr(orchestrator, "process", None)):
            raise RuntimePipelineError(
                f"orchestrator 必须实现 process(user_message) 方法,"
                f"实际: {type(orchestrator).__name__}"
            )
        self._orchestrator = orchestrator
        self._persistence_hook = persistence_hook
        self._event_sink = event_sink
        self._lifecycle_name = str(lifecycle_name or "runtime_pipeline")
        self._token_optimizer = token_optimizer
        self._lock = threading.RLock()
        # 统计
        self._run_count: int = 0
        self._success_count: int = 0
        self._failure_count: int = 0

    # --------------------------------------------------------
    # 属性
    # --------------------------------------------------------
    @property
    def orchestrator(self) -> Any:
        return self._orchestrator

    @property
    def persistence_hook(self) -> Optional[Any]:
        return self._persistence_hook

    @property
    def event_sink(self) -> Optional[Any]:
        return self._event_sink

    @property
    def token_optimizer(self) -> Optional[Any]:
        return self._token_optimizer

    @property
    def run_count(self) -> int:
        with self._lock:
            return self._run_count

    @property
    def success_count(self) -> int:
        with self._lock:
            return self._success_count

    @property
    def failure_count(self) -> int:
        with self._lock:
            return self._failure_count

    # --------------------------------------------------------
    # 核心入口
    # --------------------------------------------------------
    def run(self, input_data: Any) -> "RuntimeContext":
        """执行一次完整生命周期。

        Args:
            input_data: dict / str / 任意。Pipeline 期望 dict 含 ``user_message``,
                也可接受 str(直接作为 user_message)。

        Returns:
            RuntimeContext 实例(永远返回,失败时 state=failed)。

        流程:
            1) 解析 user_message
            2) 创建 RuntimeContext (state=initial)
            3) state -> running
            4) 【Phase 6.5】token_optimizer.optimize(user_message)  (可选)
               任何异常 -> fallback 原始输入,不影响主流程。
            5) 调用 orchestrator.process(optimized_user_message)
            6) 写入 context.outputs(契约结构 v1.0)
            7) success / failed 终态
            8) persistence_hook.persist(context)  (可选)
            9) event_sink.emit(...)                  (可选)
        """
        # 0) 延迟 import RuntimeContext
        from src.runtime.lifecycle_context import (
            LIFECYCLE_STATE_FAILED,
            LIFECYCLE_STATE_RUNNING,
            LIFECYCLE_STATE_SUCCESS,
            RuntimeContext,
        )

        # 1) 解析 user_message
        user_message = self._extract_user_message(input_data)

        # 2) 创建 RuntimeContext
        session_id = self._build_session_id()
        lifecycle_id = self._build_lifecycle_id()
        try:
            context = RuntimeContext(
                session_id=session_id,
                lifecycle_id=lifecycle_id,
                inputs={"user_message": user_message},
                metadata={
                    "pipeline": "runtime_pipeline",
                    "schema_version": RUNTIME_PIPELINE_SCHEMA_VERSION,
                },
            )
        except Exception as exc:  # noqa: BLE001
            # 极端:context 创建失败
            logger.error("[RuntimePipeline] RuntimeContext 创建失败: %s", exc)
            raise RuntimePipelineError(f"无法创建 RuntimeContext: {exc}") from exc

        with self._lock:
            self._run_count += 1

        # 3) state -> running
        try:
            context = context.with_update(state=LIFECYCLE_STATE_RUNNING)
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "[RuntimePipeline] 无法切到 running: %s", exc,
            )

        started = time.time()
        reply: str = ""
        orch_error: Optional[str] = None
        # Phase 6.5: token 优化结果(由 _safe_optimize_tokens 写入)
        token_usage: Optional[Dict[str, Any]] = None
        # Phase 6.5: 实际送入 Orchestrator 的 user_message(可能被优化)
        effective_user_message: str = user_message
        try:
            # 4) 【Phase 6.5】Token 优化(异常隔离)
            effective_user_message, token_usage = self._safe_optimize_tokens(
                user_message, input_data,
            )

            # 5) Orchestrator 调用
            try:
                raw_reply = self._orchestrator.process(effective_user_message)
            except Exception as exc:  # noqa: BLE001
                # Orchestrator.process 内部已隔离,理论上不会抛;兜底
                logger.warning(
                    "[RuntimePipeline] orchestrator.process 抛错(已隔离): %s", exc,
                )
                raw_reply = ""
                try:
                    orch_error = f"{type(exc).__name__}: {exc}"
                except Exception:  # noqa: BLE001
                    orch_error = "unknown orchestrator error"

            # 6) 规范化 reply
            if isinstance(raw_reply, str) and raw_reply.strip():
                reply = raw_reply
            else:
                reply = ""

            # 7) 写入 context.outputs
            duration_ms = max(0, int((time.time() - started) * 1000))
            outputs = self._build_outputs(
                user_message=user_message,
                effective_user_message=effective_user_message,
                reply=reply,
                duration_ms=duration_ms,
                orchestrator=getattr(self._orchestrator, "__class__", type(self._orchestrator)).__name__,
                token_usage=token_usage,
            )
            try:
                context = context.with_update(outputs=outputs)
            except Exception as exc:  # noqa: BLE001
                logger.warning("[RuntimePipeline] 写入 outputs 失败: %s", exc)

            # 8) 判定终态
            if reply and not orch_error:
                try:
                    context = context.mark_success(outputs=outputs)
                except Exception as exc:  # noqa: BLE001
                    logger.warning("[RuntimePipeline] mark_success 失败: %s", exc)
                    context = self._force_failed(context, str(exc))
                with self._lock:
                    self._success_count += 1
            else:
                err = orch_error or "empty reply from orchestrator"
                try:
                    context = context.mark_failed(err)
                except Exception as exc:  # noqa: BLE001
                    logger.warning("[RuntimePipeline] mark_failed 失败: %s", exc)
                    context = self._force_failed(context, str(exc))
                with self._lock:
                    self._failure_count += 1

        except Exception as exc:  # noqa: BLE001
            # 极端兜底
            logger.exception("[RuntimePipeline] 未知异常: %s", exc)
            try:
                err_str = f"{type(exc).__name__}: {exc}"
            except Exception:  # noqa: BLE001
                err_str = "unknown error"
            context = self._force_failed(context, err_str)
            with self._lock:
                self._failure_count += 1

        # 9) 持久化(异常隔离)
        if self._persistence_hook is not None:
            self._safe_persist(context)

        # 10) 事件发布(异常隔离)
        if self._event_sink is not None:
            self._safe_emit(context)

        return context

    # --------------------------------------------------------
    # 辅助
    # --------------------------------------------------------
    def _extract_user_message(self, input_data: Any) -> str:
        """从 input_data 提取 user_message。"""
        if isinstance(input_data, str):
            return input_data
        if isinstance(input_data, dict):
            um = input_data.get("user_message")
            if isinstance(um, str):
                return um
            # 退化:取 dict 第一个 str 值
            for v in input_data.values():
                if isinstance(v, str):
                    return v
        return str(input_data) if input_data is not None else ""

    def _build_session_id(self) -> str:
        return f"pipe_{uuid.uuid4().hex[:12]}"

    def _build_lifecycle_id(self) -> str:
        return f"pipeline_{uuid.uuid4().hex[:12]}"

    def _build_outputs(
        self,
        *,
        user_message: str,
        reply: str,
        duration_ms: int,
        orchestrator: str,
        effective_user_message: Optional[str] = None,
        token_usage: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """构造 context.outputs(契约结构 v1.0,与 Bridge 保持一致)。

        Phase 6.5 扩展:
            - ``effective_user_message`` 经 token 优化后实际送入
              Orchestrator 的 user_message;若未启用 token_optimizer,
              与 ``user_message`` 相同,字段省略不输出。
            - ``token_usage`` 仅在启用 token_optimizer 时写入,结构:
              {before_tokens, after_tokens, saved_tokens,
               compression_ratio, applied?, fallback_reason?}
              未启用时,字段不写入,保持向后兼容。
        """
        snapshot: Dict[str, Any] = {
            "user_message": user_message,
            "reply": reply,
            "orchestrator": orchestrator,
        }
        # Phase 6.5: 仅在 token_optimizer 启用(且产生了 effective_user_message)时
        # 才记录,避免污染历史 outputs 契约
        if effective_user_message is not None and effective_user_message != user_message:
            snapshot["effective_user_message"] = effective_user_message
        if token_usage is not None and isinstance(token_usage, dict):
            snapshot["token_usage"] = token_usage

        return {
            "lifecycle": {
                "name": self._lifecycle_name,
                "status": "success" if reply else "failed",
                "duration_ms": duration_ms,
                "summary": {
                    "total": 1,
                    "success": 1 if reply else 0,
                    "failed": 0 if reply else 1,
                    "skipped": 0,
                    "fatal": 0,
                    "timeout": 0,
                    "cancelled": 0,
                    "task_ids": [orchestrator],
                    "errors": [],
                },
            },
            "snapshot": snapshot,
        }

    def _force_failed(self, context: Any, err: str) -> Any:
        """强制将 context 切到 failed(兜底)。"""
        from src.runtime.lifecycle_context import LIFECYCLE_STATE_FAILED
        try:
            return context.with_update(
                state=LIFECYCLE_STATE_FAILED, error=err,
            ).mark_failed(err)
        except Exception:  # noqa: BLE001
            return context

    def _safe_optimize_tokens(
        self,
        user_message: str,
        input_data: Any,
    ) -> tuple:
        """Phase 6.5 —— 安全调用 token_optimizer(异常隔离)。

        行为契约:
            - token_optimizer 为 None -> 返回 (user_message, None),
              不修改 context.outputs(零侵入)。
            - token_optimizer.optimize() 抛错 -> 兜底返回 (user_message,
              fallback 标记),**绝不**让异常影响主流程。
            - 返回的 tuple:
                (
                    effective_user_message: str,
                    token_usage: Optional[Dict[str, Any]]
                )

        Args:
            user_message: 已提取的原始 user_message(必定为 str)
            input_data: Pipeline.run() 接收的原始 input(供 optimizer 透传
                history / memories 等辅助输入使用)。

        Returns:
            (effective_user_message, token_usage_dict or None)
        """
        # 1) 禁用路径
        if self._token_optimizer is None:
            return user_message, None

        # 2) 校验:必须有 optimize 方法
        optimize_fn = getattr(self._token_optimizer, "optimize", None)
        if not callable(optimize_fn):
            logger.warning(
                "[RuntimePipeline] token_optimizer 缺少 optimize() 方法,"
                "已忽略(原始 user_message 直接送入 Orchestrator)",
            )
            return user_message, None

        # 3) 收集 history / memories(从 input_data 中尽量提取)
        history: Optional[list] = None
        memories: Optional[list] = None
        try:
            if isinstance(input_data, dict):
                h = input_data.get("history")
                if isinstance(h, list):
                    history = h
                m = input_data.get("memories")
                if isinstance(m, list):
                    memories = m
        except Exception:  # noqa: BLE001
            history = None
            memories = None

        # 4) 调用 optimize(异常隔离)
        try:
            result = optimize_fn(user_message, history, memories)
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "[RuntimePipeline] token_optimizer.optimize 抛错(已隔离,使用原始输入): %s",
                exc,
            )
            # 兜底:写入 fallback token_usage,但不修改 user_message
            return user_message, {
                "before_tokens": 0,
                "after_tokens": 0,
                "saved_tokens": 0,
                "compression_ratio": 1.0,
                "applied": False,
                "fallback_reason": (
                    f"optimizer_exception: {type(exc).__name__}: {str(exc)[:120]}"
                ),
            }

        # 5) 防御性解析结果
        if not isinstance(result, dict):
            logger.warning(
                "[RuntimePipeline] token_optimizer 返回非 dict(%s),"
                "已忽略(原始 user_message 直接送入 Orchestrator)",
                type(result).__name__,
            )
            return user_message, None

        # 5.1) 提取 content(允许空字符串)
        content = result.get("content")
        if not isinstance(content, str):
            # 缺/非 str -> 视为 NoOp
            content = user_message

        # 5.2) 提取 token_usage(委托给 adapter)
        try:
            from src.runtime.token_optimizer import build_token_usage
            token_usage = build_token_usage(result)
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "[RuntimePipeline] build_token_usage 抛错(已隔离): %s", exc,
            )
            token_usage = {
                "before_tokens": 0,
                "after_tokens": 0,
                "saved_tokens": 0,
                "compression_ratio": 1.0,
                "applied": False,
                "fallback_reason": "build_token_usage_exception",
            }

        return content, token_usage

    def _safe_persist(self, context: Any) -> None:
        """安全调用 persistence_hook(异常隔离)。"""
        try:
            persist_fn = getattr(self._persistence_hook, "persist", None)
            if not callable(persist_fn):
                return
            try:
                persist_fn(context)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "[RuntimePipeline] persistence_hook.persist 抛错(已隔离): %s", exc,
                )
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "[RuntimePipeline] persistence_hook 调用异常(已隔离): %s", exc,
            )

    def _safe_emit(self, context: Any) -> None:
        """安全调用 event_sink(异常隔离)。"""
        try:
            emit_fn = getattr(self._event_sink, "emit", None)
            if not callable(emit_fn):
                return
            event = {
                "event_type": "runtime.pipeline.completed",
                "lifecycle_id": getattr(context, "lifecycle_id", ""),
                "session_id": getattr(context, "session_id", ""),
                "state": getattr(context, "state", ""),
                "timestamp": time.time(),
                "schema_version": RUNTIME_PIPELINE_SCHEMA_VERSION,
            }
            try:
                emit_fn(event)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "[RuntimePipeline] event_sink.emit 抛错(已隔离): %s", exc,
                )
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "[RuntimePipeline] event_sink 调用异常(已隔离): %s", exc,
            )

    def __repr__(self) -> str:
        return (
            f"RuntimePipeline(orchestrator={type(self._orchestrator).__name__}, "
            f"persistence={'yes' if self._persistence_hook else 'no'}, "
            f"event_sink={'yes' if self._event_sink else 'no'}, "
            f"token_optimizer={'yes' if self._token_optimizer else 'no'})"
        )


__all__ = [
    "RUNTIME_PIPELINE_SCHEMA_VERSION",
    "OrchestratorLike",
    "EventSinkLike",
    "TokenOptimizerLike",
    "RuntimePipelineError",
    "RuntimePipeline",
]
