# -*- coding: utf-8 -*-
"""
src/runtime/self_model/__init__.py

Phase 4.2.1: Self Model Foundation —— 模块入口
Phase 4.2.2: Self Model Integration —— 新增 SourceAdapter 层
Phase 5.0-D3-A: Self Model System —— 运行时核心 + 适配 + 周期 Task

约束:
- 不 import openai / qwen / llava / vision SDK
- 不 import src.personality.self_model_manager / self_model_v3 等
- 不修改 RuntimeContext / Fact / Observation schema
- Runtime 只通过本模块访问 SelfModel Foundation
- SelfModel 不允许 import 任何业务模块
"""

from __future__ import annotations

from src.runtime.self_model.self_model_data import (
    SELF_MODEL_FOUNDATION_SCHEMA_VERSION,
    SelfModelEntry,
    SelfModelSnapshot,
    VALID_ENTRY_KINDS,
    MAX_ENTRIES,
    MAX_VALUES,
    MAX_TRAITS,
    MAX_PREFERENCES,
)
from src.runtime.self_model.self_model_foundation import (
    SelfModelFoundation,
    SelfModelBuilderBase,
    DEFAULT_IDENTITY,
    DEFAULT_CORE_VALUES,
)
from src.runtime.self_model.self_model_registry import (
    SelfModelRegistry,
    SELF_MODEL_REGISTRY_SCHEMA_VERSION,
)
# Phase 4.2.2: Source Adapter Layer
from src.runtime.self_model.self_model_source_adapter import (
    SelfModelSourceAdapter,
    SELF_MODEL_SOURCE_ADAPTER_SCHEMA_VERSION,
    SOURCE_TYPE_GROWTH,
    SOURCE_TYPE_MEMORY,
    SOURCE_TYPE_PERSONALITY,
    SOURCE_TYPE_EMOTION,
    VALID_SOURCE_TYPES,
)
from src.runtime.self_model.growth_self_model_adapter import (
    GrowthSelfModelAdapter,
    GROWTH_SELF_MODEL_ADAPTER_NAME,
)
from src.runtime.self_model.memory_self_model_adapter import (
    MemorySelfModelAdapter,
    MEMORY_SELF_MODEL_ADAPTER_NAME,
)
from src.runtime.self_model.personality_self_model_adapter import (
    PersonalitySelfModelAdapter,
    PERSONALITY_SELF_MODEL_ADAPTER_NAME,
)
from src.runtime.self_model.emotion_self_model_adapter import (
    EmotionSelfModelAdapter,
    EMOTION_SELF_MODEL_ADAPTER_NAME,
)
# Phase 4.2.3: SelfModel → Response Context Provider
from src.runtime.self_model.self_model_context_provider import (
    SelfModelContextProvider,
    SELF_MODEL_CONTEXT_PROVIDER_SCHEMA_VERSION,
    MAX_RECENT_CHANGES as SELF_MODEL_CONTEXT_MAX_RECENT_CHANGES,
    RECENT_CHANGE_KINDS as SELF_MODEL_CONTEXT_RECENT_CHANGE_KINDS,
)
# Phase 4.5: SelfModel Evolution Engine
from src.runtime.self_model.evolution import (
    SelfModelChange as EvolutionSelfModelChange,
    EvolutionRecord,
    EvolutionSourceType,
    SelfModelEvolutionResult,
    EVOLUTION_RECORD_SCHEMA_VERSION as SELF_MODEL_EVOLUTION_RECORD_SCHEMA_VERSION,
    EvolutionPolicy,
    EvolutionVerdict,
    EvolutionPolicyDecision,
    ALLOWED_FIELDS as EVOLUTION_ALLOWED_FIELDS,
    CAUTIOUS_FIELDS as EVOLUTION_CAUTIOUS_FIELDS,
    FORBIDDEN_FIELDS as EVOLUTION_FORBIDDEN_FIELDS,
    DEFAULT_MIN_CONFIDENCE as EVOLUTION_DEFAULT_MIN_CONFIDENCE,
    DEFAULT_CAUTIOUS_MIN_CONFIDENCE as EVOLUTION_DEFAULT_CAUTIOUS_MIN_CONFIDENCE,
    EVOLUTION_POLICY_SCHEMA_VERSION,
    SelfModelEvolutionEngine,
    SELF_MODEL_EVOLUTION_ENGINE_SCHEMA_VERSION,
)
# Phase 4.6: Self Model Persistence & Evolution History Layer
from src.runtime.self_model.persistence import (
    SelfModelStore as SelfModelStoreImpl,
    SELF_MODEL_STORE_SCHEMA_VERSION,
    DEFAULT_SELF_MODEL_DIR,
    MAX_SNAPSHOT_FILE_BYTES,
    EvolutionHistoryStore as EvolutionHistoryStoreImpl,
    EVOLUTION_HISTORY_STORE_SCHEMA_VERSION,
    DEFAULT_EVOLUTION_HISTORY_DIR,
    MAX_HISTORY_FILE_BYTES,
    SnapshotManager as SnapshotManagerImpl,
    SNAPSHOT_MANAGER_SCHEMA_VERSION,
    CHECKPOINT_PREFIX,
    CHECKPOINT_FORMAT_VERSION,
    PersistenceRuntime as PersistenceRuntimeImpl,
    PERSISTENCE_RUNTIME_SCHEMA_VERSION,
)
# Phase 5.0-D3-A: Self Model System Runtime Core
from src.runtime.self_model.self_state import (
    SELF_MODEL_STATE_SCHEMA_VERSION,
    IdentityView,
    TraitState,
    CapabilityState,
    InterestState,
    ChangeRecord,
    SelfState,
    MAX_TRAITS,
    MAX_CAPABILITIES,
    MAX_INTERESTS,
    VALID_TRAIT_DIRECTIONS,
    VALID_CHANGE_KINDS,
    VALID_CHANGE_SOURCES,
    build_default_self_state,
)
from src.runtime.self_model.change_log import (
    CHANGE_LOG_SCHEMA_VERSION,
    DEFAULT_CHANGE_LOG_CAPACITY,
    MAX_CHANGE_LOG_CAPACITY,
    ChangeLog,
    ChangeLogError,
    build_default_change_log,
)
from src.runtime.self_model.self_model_manager import (
    SELF_MODEL_MANAGER_SCHEMA_VERSION,
    SelfModelManager,
    SelfModelManagerError,
    build_default_self_model_manager,
)
from src.runtime.self_model.self_model_adapter import (
    SELF_MODEL_ADAPTER_SCHEMA_VERSION,
    SelfModelAdapter,
    SELF_MODEL_TRAIT_REINFORCED,
    SELF_MODEL_INTEREST_REINFORCED,
    SELF_MODEL_CAPABILITY_USED,
    SELF_MODEL_SNAPSHOT_REFRESHED,
    SELF_MODEL_CHANGE_RECORDED,
    build_default_self_model_adapter,
)
from src.runtime.self_model.self_model_lifecycle_task import (
    SELF_MODEL_LIFECYCLE_TASK_SCHEMA_VERSION,
    SelfModelLifecycleTask,
    build_default_self_model_lifecycle_task,
)


__all__ = [
    # 数据
    "SELF_MODEL_FOUNDATION_SCHEMA_VERSION",
    "SelfModelEntry",
    "SelfModelSnapshot",
    "VALID_ENTRY_KINDS",
    "MAX_ENTRIES",
    "MAX_VALUES",
    "MAX_TRAITS",
    "MAX_PREFERENCES",
    # Foundation
    "SelfModelFoundation",
    "SelfModelBuilderBase",
    "DEFAULT_IDENTITY",
    "DEFAULT_CORE_VALUES",
    # Registry
    "SelfModelRegistry",
    "SELF_MODEL_REGISTRY_SCHEMA_VERSION",
    # Phase 4.2.2: Source Adapter
    "SelfModelSourceAdapter",
    "SELF_MODEL_SOURCE_ADAPTER_SCHEMA_VERSION",
    "SOURCE_TYPE_GROWTH",
    "SOURCE_TYPE_MEMORY",
    "SOURCE_TYPE_PERSONALITY",
    "SOURCE_TYPE_EMOTION",
    "VALID_SOURCE_TYPES",
    "GrowthSelfModelAdapter",
    "GROWTH_SELF_MODEL_ADAPTER_NAME",
    "MemorySelfModelAdapter",
    "MEMORY_SELF_MODEL_ADAPTER_NAME",
    "PersonalitySelfModelAdapter",
    "PERSONALITY_SELF_MODEL_ADAPTER_NAME",
    "EmotionSelfModelAdapter",
    "EMOTION_SELF_MODEL_ADAPTER_NAME",
    # Phase 4.2.3: SelfModel → Response Context Provider
    "SelfModelContextProvider",
    "SELF_MODEL_CONTEXT_PROVIDER_SCHEMA_VERSION",
    "SELF_MODEL_CONTEXT_MAX_RECENT_CHANGES",
    "SELF_MODEL_CONTEXT_RECENT_CHANGE_KINDS",
    # Phase 4.5: SelfModel Evolution Engine
    "EvolutionSelfModelChange",
    "EvolutionRecord",
    "EvolutionSourceType",
    "SelfModelEvolutionResult",
    "SELF_MODEL_EVOLUTION_RECORD_SCHEMA_VERSION",
    "EvolutionPolicy",
    "EvolutionVerdict",
    "EvolutionPolicyDecision",
    "EVOLUTION_ALLOWED_FIELDS",
    "EVOLUTION_CAUTIOUS_FIELDS",
    "EVOLUTION_FORBIDDEN_FIELDS",
    "EVOLUTION_DEFAULT_MIN_CONFIDENCE",
    "EVOLUTION_DEFAULT_CAUTIOUS_MIN_CONFIDENCE",
    "EVOLUTION_POLICY_SCHEMA_VERSION",
    "SelfModelEvolutionEngine",
    "SELF_MODEL_EVOLUTION_ENGINE_SCHEMA_VERSION",
    # Phase 4.6: Self Model Persistence & Evolution History Layer
    "SelfModelStoreImpl",
    "SELF_MODEL_STORE_SCHEMA_VERSION",
    "DEFAULT_SELF_MODEL_DIR",
    "MAX_SNAPSHOT_FILE_BYTES",
    "EvolutionHistoryStoreImpl",
    "EVOLUTION_HISTORY_STORE_SCHEMA_VERSION",
    "DEFAULT_EVOLUTION_HISTORY_DIR",
    "MAX_HISTORY_FILE_BYTES",
    "SnapshotManagerImpl",
    "SNAPSHOT_MANAGER_SCHEMA_VERSION",
    "CHECKPOINT_PREFIX",
    "CHECKPOINT_FORMAT_VERSION",
    "PersistenceRuntimeImpl",
    "PERSISTENCE_RUNTIME_SCHEMA_VERSION",
    # Phase 5.0-D3-A: Self Model System Runtime Core
    "SELF_MODEL_STATE_SCHEMA_VERSION",
    "IdentityView",
    "TraitState",
    "CapabilityState",
    "InterestState",
    "ChangeRecord",
    "SelfState",
    "MAX_TRAITS",
    "MAX_CAPABILITIES",
    "MAX_INTERESTS",
    "VALID_TRAIT_DIRECTIONS",
    "VALID_CHANGE_KINDS",
    "VALID_CHANGE_SOURCES",
    "build_default_self_state",
    # ChangeLog
    "CHANGE_LOG_SCHEMA_VERSION",
    "DEFAULT_CHANGE_LOG_CAPACITY",
    "MAX_CHANGE_LOG_CAPACITY",
    "ChangeLog",
    "ChangeLogError",
    "build_default_change_log",
    # SelfModelManager
    "SELF_MODEL_MANAGER_SCHEMA_VERSION",
    "SelfModelManager",
    "SelfModelManagerError",
    "build_default_self_model_manager",
    # SelfModelAdapter
    "SELF_MODEL_ADAPTER_SCHEMA_VERSION",
    "SelfModelAdapter",
    "SELF_MODEL_TRAIT_REINFORCED",
    "SELF_MODEL_INTEREST_REINFORCED",
    "SELF_MODEL_CAPABILITY_USED",
    "SELF_MODEL_SNAPSHOT_REFRESHED",
    "SELF_MODEL_CHANGE_RECORDED",
    "build_default_self_model_adapter",
    # SelfModelLifecycleTask
    "SELF_MODEL_LIFECYCLE_TASK_SCHEMA_VERSION",
    "SelfModelLifecycleTask",
    "build_default_self_model_lifecycle_task",
]
