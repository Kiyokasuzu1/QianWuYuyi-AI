"""
RuntimeCore —— 羽依的生命循环系统

职责：
- 维护世界状态（WorldState）和自身状态（SelfState）
- 接收事件并更新状态
- 周期性决策（DecisionEngine）
- 行动分发（ActionDispatcher）
- 状态持久化

生命周期：
    启动 → 加载状态 → 订阅事件 → 启动调度器 → 运行
    停止 → 保存状态 → 停止调度器 → 结束

设计原则：
- 继承 ModuleBase，可被管理面板控制
- 低耦合：通过事件与其他模块通信
- 可恢复：状态持久化到文件
"""

import json
import logging
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from src.core.module_interface import ModuleBase
from src.runtime.self_state import SelfState
from src.runtime.world_state import WorldState
from src.runtime.decision_engine import DecisionEngine
from src.runtime.action_dispatcher import ActionDispatcher, Action
from src.runtime.scheduler import Scheduler
from src.runtime.event_bus import RuntimeEventBus
from src.runtime.runtime_event_bus import RuntimeEventBus as DomainRuntimeEventBus
from src.runtime.cognitive_engine import CognitiveEngine
from src.contracts.cognitive_schema import DecisionContext
from src.runtime.experience_builder import ExperienceBuilder, ExperienceBuilderConfig
from src.runtime.reflection_engine import ReflectionEngine, ReflectionEngineConfig
from src.runtime.self_reflection_engine import SelfReflectionEngine
from src.runtime.curiosity_engine import CuriosityEngine
from src.runtime.creative_engine import CreativeEngine
from src.contracts.experience_schema import ActionResult
from src.runtime.adapters.memory_adapter import MemoryAdapter
from src.runtime.adapters.growth_adapter import GrowthAdapter
from src.runtime.adapters.proposal_evaluator import ProposalEvaluator, EvaluationResult, EvaluationThresholds
from src.personality.personality_adapter import PersonalityAdapter, PersonalityChangeRequest
from src.personality.personality_resolver import PersonalityResolver
from src.personality.personality_evolution_pipeline import PersonalityEvolutionPipeline
from src.personality.self_model_manager import SelfModelManager
from src.personality.self_model_updater import SelfModelUpdater, SelfModelUpdaterConfig
from src.contracts.self_model_schema import SelfModelChangeSuggestion
from src.memory.memory_relevance_evaluator import MemoryRelevanceEvaluator
from src.memory.memory_consolidation_engine import MemoryConsolidationEngine
from src.emotion.emotion_manager import EmotionManager
from src.emotion.emotion_event import EmotionEvent
from src.emotion.emotion_dynamics_engine import EmotionDynamicsEngine
from src.relationship.relationship_repository import RelationshipRepository
from src.relationship.relationship_state import RelationshipState
from src.relationship.relationship_model import RelationshipModel, RelationshipIntelligenceEngine
from src.personality.identity_continuity import (
    IdentityContinuityChecker,
    IdentityContinuityHistory,
    ContinuityThresholds,
)
from src.contracts.identity_schema import (
    IdentitySnapshot,
    ContinuityReport,
)
from src.personality.identity_anchor import IdentityAnchorManager
from src.contracts.identity_anchor_schema import (
    IdentityAnchor,
    AnchorSnapshot,
    AnchorChangeProposal,
    AnchorIntegrityReport,
)
from src.personality.identity_stability_engine import (
    IdentityStabilityEngine,
    IdentityStabilityEngineConfig,
)
from src.personality.personality_stability_engine import (
    PersonalityStabilityEngine,
    PersonalityStabilityConfig,
)
from src.contracts.identity_stability_schema import (
    IdentityStabilityReport,
    IdentityStabilitySnapshot,
)
from src.contracts.personality_stability_schema import PersonalityStabilityReport
from src.runtime.reflection_scheduler import (
    ReflectionScheduler,
    ReflectionSchedule,
    ReflectionTrigger,
    ReflectionTriggerConfig,
)
from src.contracts.reflection_scheduler_schema import (
    TriggerResult,
    ReflectionTaskRecord,
    SchedulerSnapshot,
)
from src.runtime.reflection_evaluator import (
    ReflectionEvaluator,
    EvaluatorConfig,
)
from src.contracts.reflection_evaluation_schema import (
    ReflectionEvaluation,
    EvaluationHistoryEntry,
    EvaluatorSnapshot,
    SOURCE_REFLECTION_INSIGHT,
    SOURCE_GROWTH_RECORD,
    SOURCE_IDENTITY_CHANGE,
    SOURCE_RELATIONSHIP,
    RECOMMENDATION_ACCEPT,
    RECOMMENDATION_REJECT,
    RECOMMENDATION_DEFER,
    RECOMMENDATION_REVISIT,
)
from src.runtime.reflection_growth_bridge import (
    ReflectionGrowthBridge,
    ReflectionGrowthBridgeConfig,
)
from src.contracts.reflection_growth_schema import (
    ReflectionGrowthRecord,
    ReflectionGrowthSnapshot,
)
from src.growth.approval_manager import ApprovalManager
from src.contracts.growth_approval_schema import (
    ApprovalRecord,
    ApprovalHistory,
    ApprovalSnapshot,
    ChangeDiff,
    ACTION_APPROVE,
    ACTION_REJECT,
    ACTION_MODIFY,
)
from src.runtime.lifecycle_manager import LifecycleManager
from src.runtime.lifecycle_orchestrator import RuntimeLifecycleOrchestrator
from src.runtime.autonomous_decision_layer import (
    AutonomousDecisionLayer,
    AutonomousDecisionConfig,
)
from src.runtime.autonomous_scheduler import (
    AutonomousScheduler,
    AutonomousSchedulerConfig,
)
from src.runtime.runtime_integration_manager import RuntimeIntegrationManager
from src.contracts.runtime_integration_schema import (
    RuntimeHealthReport,
    RuntimeSubsystemStatus,
)
from src.contracts.runtime_event_schema import (
    EVENT_EXPERIENCE_CREATED,
    EVENT_MEMORY_CREATED,
    EVENT_REFLECTION_STARTED,
    EVENT_REFLECTION_COMPLETED,
    EVENT_EVALUATION_COMPLETED,
    EVENT_PROPOSAL_CREATED,
    EVENT_PROPOSAL_APPLIED,
    EVENT_IDENTITY_CHANGED,
    EVENT_EMOTION_CHANGED,
    EVENT_RELATIONSHIP_CHANGED,
)
from src.contracts.lifecycle_schema import (
    PHASE_INIT, PHASE_START, PHASE_RESUME, PHASE_RUN,
    PHASE_SAVE, PHASE_STOP, PHASE_ERROR,
    ModuleStatus,
    LifecycleRecord,
    LifecycleSnapshot,
    RuntimeLifecycleState,
    RuntimeLifecycleEvent,
    STAGE_EXPERIENCE_RECEIVED,
    STAGE_MEMORY_CREATED,
    STAGE_REFLECTION_STARTED,
    STAGE_EVALUATION_COMPLETED,
    STAGE_PROPOSAL_CREATED,
    STAGE_PROPOSAL_APPLIED,
)
from src.runtime.personality_event_bus import PersonalityEventBus
from src.contracts.personality_event_schema import (
    PersonalityEvent,
    EventFilter,
    EventBusSnapshot,
    CATEGORY_MEMORY,
    CATEGORY_GROWTH,
    CATEGORY_REFLECTION,
    CATEGORY_IDENTITY,
    CATEGORY_RELATIONSHIP,
)

logger = logging.getLogger(__name__)

DEFAULT_STATE_FILE = "data/runtime_state.json"
DEFAULT_TICK_INTERVAL = 60.0


class RuntimeCore(ModuleBase):
    """
    Runtime 核心

    羽依的"生命主循环"，负责状态维护、事件响应、决策和行动。
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        super().__init__("runtime", config)
        self.world_state = WorldState()
        self.self_state = SelfState.default()
        self.decision_engine = DecisionEngine(config=self.config.get("decision", {}))
        self.action_dispatcher = ActionDispatcher()
        self.scheduler = Scheduler()
        self.event_bus = RuntimeEventBus()
        self.domain_event_bus = DomainRuntimeEventBus()
        self._last_tick = 0.0
        self._tick_interval = self.config.get("tick_interval_seconds", DEFAULT_TICK_INTERVAL)
        self._state_file = Path(self.config.get("state_file", DEFAULT_STATE_FILE))
        self._decision_confidence_threshold = self.config.get("decision_confidence_threshold", 0.5)
        self._tick_count = 0
        self._event_driven_enabled: bool = self.config.get("event_driven_enabled", True)

        # Phase 3.5.4: 认知决策层（可选）
        self.cognitive_engine: Optional[CognitiveEngine] = None
        if self.config.get("cognitive_enabled", False):
            self.cognitive_engine = CognitiveEngine(
                config=self.config.get("cognitive", {}),
                llm_enabled=self.config.get("cognitive_llm_enabled", False),
            )

        # Phase 3.5.5: 经验与反思层（可选）
        self.experience_builder: Optional[ExperienceBuilder] = None
        self.reflection_engine: Optional[ReflectionEngine] = None
        self.self_reflection_engine: Optional[SelfReflectionEngine] = None
        self.curiosity_engine: Optional[CuriosityEngine] = None
        self.creative_engine: Optional[CreativeEngine] = None
        self._self_reflection_enabled: bool = self.config.get("self_reflection_enabled", self.config.get("experience_enabled", False))
        self._curiosity_enabled: bool = self.config.get("curiosity_enabled", self._self_reflection_enabled)
        self._creativity_enabled: bool = self.config.get("creativity_enabled", self._curiosity_enabled)
        if self.config.get("experience_enabled", False):
            self.experience_builder = ExperienceBuilder(
                config=ExperienceBuilderConfig(
                    auto_validate=self.config.get("experience_auto_validate", True),
                    auto_flush=self.config.get("experience_auto_flush", False),
                ),
            )
            self.reflection_engine = ReflectionEngine(
                config=ReflectionEngineConfig(
                    llm_enabled=self.config.get("reflection_llm_enabled", False),
                ),
            )
            if self._self_reflection_enabled:
                self.self_reflection_engine = SelfReflectionEngine(
                    history_limit=int(self.config.get("self_reflection_history_limit", 300)),
                )
            if self._curiosity_enabled:
                self.curiosity_engine = CuriosityEngine(
                    history_limit=int(self.config.get("curiosity_history_limit", 200)),
                )
            if self._creativity_enabled:
                self.creative_engine = CreativeEngine(
                    history_limit=int(self.config.get("creative_history_limit", 200)),
                )

        # Phase 3.5.6: 经验与成长适配器（可选）
        self.memory_adapter: Optional[MemoryAdapter] = None
        self.growth_adapter: Optional[GrowthAdapter] = None
        self.memory_relevance_evaluator: Optional[MemoryRelevanceEvaluator] = None
        self.memory_consolidation_engine: Optional[MemoryConsolidationEngine] = None
        # Phase 3.5.7: Proposal 评估与人格成长适配器（可选，与 adapters_enabled 联动）
        self.proposal_evaluator: Optional[ProposalEvaluator] = None
        self.personality_adapter: Optional[PersonalityAdapter] = None
        self.personality_resolver: Optional[PersonalityResolver] = None
        self.personality_evolution_pipeline: Optional[PersonalityEvolutionPipeline] = None
        # Phase 3.5.7: 已生成但未应用的 PersonalityChangeRequest (in-memory)
        self._pending_change_requests: List[PersonalityChangeRequest] = []
        # Phase 3.5.8: Self Model 系统（可选，与 adapters_enabled 联动）
        self.self_model_manager: Optional[SelfModelManager] = None
        self.self_model_updater: Optional[SelfModelUpdater] = None
        self._pending_self_model_suggestions: List[SelfModelChangeSuggestion] = []
        # Phase 6.3: SelfModelAdapter + Bootstrap（默认开启；失败不阻塞）
        self._self_model_adapter: Any = None
        self._self_model_bootstrap: Any = None
        self._self_model_bootstrap_envelope: Dict[str, Any] = {}
        # Phase 3.5.9: Identity Continuity Layer（可选，默认关闭）
        self.identity_continuity_checker: Optional[IdentityContinuityChecker] = None
        self.identity_continuity_history: Optional[IdentityContinuityHistory] = None
        self._last_identity_snapshot: Optional[IdentitySnapshot] = None
        self._identity_continuity_enabled: bool = self.config.get("identity_continuity_enabled", False)
        # Phase 3.5.17: Identity Stability Engine（可选，默认与 continuity 同步）
        self.identity_stability_engine: Optional[IdentityStabilityEngine] = None
        self._identity_stability_enabled: bool = self.config.get(
            "identity_stability_enabled",
            self._identity_continuity_enabled,
        )
        # Phase 3.5.26: Personality Stability Engine（可选，默认跟随 identity stability）
        self.personality_stability_engine: Optional[PersonalityStabilityEngine] = None
        self._personality_stability_enabled: bool = self.config.get(
            "personality_stability_enabled",
            self._identity_stability_enabled,
        )
        # Phase 3.5.10: Identity Anchor System（可选，默认关闭）
        self.identity_anchor_manager: Optional[IdentityAnchorManager] = None
        self._identity_anchor_enabled: bool = self.config.get("identity_anchor_enabled", False)
        # Phase 3.5.11: Autonomous Reflection Scheduler（可选，默认关闭）
        self.reflection_scheduler: Optional[ReflectionScheduler] = None
        self._reflection_scheduler_enabled: bool = self.config.get("reflection_scheduler_enabled", False)
        # Phase 3.5.19: Autonomous Decision Layer（可选，默认关闭）
        self.autonomous_decision_layer: Optional[AutonomousDecisionLayer] = None
        self._autonomous_decision_enabled: bool = self.config.get("autonomous_decision_enabled", False)
        # Phase 3.5.24: Autonomous Scheduler（可选，默认关闭）
        self.autonomous_scheduler: Optional[AutonomousScheduler] = None
        self._autonomous_scheduler_enabled: bool = self.config.get("autonomous_scheduler_enabled", False)
        # Phase 3.5.12: Reflection Evaluation Layer（可选，默认关闭）
        self.reflection_evaluator: Optional[ReflectionEvaluator] = None
        self._reflection_evaluator_enabled: bool = self.config.get("reflection_evaluator_enabled", False)
        # Phase 3.5.13: Reflection → Growth Integration Layer（可选，默认与 evaluator 同步）
        self.reflection_growth_bridge: Optional[ReflectionGrowthBridge] = None
        self._reflection_growth_bridge_enabled: bool = self.config.get(
            "reflection_growth_bridge_enabled",
            self._reflection_evaluator_enabled,
        )
        # Phase 3.5.13: Growth Approval Layer（可选，默认关闭）
        self.approval_manager: Optional[ApprovalManager] = None
        self._approval_manager_enabled: bool = self.config.get("approval_manager_enabled", False)
        # Phase 3.5.14: Runtime Lifecycle Integration（可选，默认关闭）
        self.lifecycle_manager: Optional[LifecycleManager] = None
        self._lifecycle_manager_enabled: bool = self.config.get("lifecycle_manager_enabled", False)
        # Phase 3.5.14: Cognitive lifecycle state machine（默认开启，轻量）
        self.lifecycle_orchestrator = RuntimeLifecycleOrchestrator(
            history_limit=int(self.config.get("runtime_lifecycle_history_limit", 500))
        )
        # Phase 3.5.15: Personality Event Bus（可选，默认关闭）
        self.personality_event_bus: Optional[PersonalityEventBus] = None
        self._personality_event_bus_enabled: bool = self.config.get("personality_event_bus_enabled", False)
        # Phase 3.5.20: Relationship / Emotion / Runtime Integration
        self.relationship_repository: Optional[RelationshipRepository] = None
        self.relationship_state_runtime: Optional[RelationshipState] = None
        self.relationship_model_runtime: Optional[RelationshipModel] = None
        self.relationship_intelligence_engine: Optional[RelationshipIntelligenceEngine] = None
        self._relationship_enabled: bool = self.config.get("relationship_enabled", False)
        self.emotion_manager: Optional[EmotionManager] = None
        self.emotion_dynamics_engine: Optional[EmotionDynamicsEngine] = None
        self._emotion_enabled: bool = self.config.get("emotion_enabled", False)
        self.runtime_integration_manager: Optional[RuntimeIntegrationManager] = None
        self._runtime_integration_enabled: bool = self.config.get("runtime_integration_enabled", False)
        self._reflection_min_experiences: int = int(self.config.get("reflection_min_experiences", 3))

        if self.config.get("adapters_enabled", False):
            # 创建 MemoryStore（支持自定义路径）
            memory_store_path = self.config.get("memory_store_path")
            memory_store = None
            if memory_store_path:
                from src.memory.memory_store import MemoryStore
                memory_store = MemoryStore(memory_store_path)

            self.memory_adapter = MemoryAdapter(
                memory_store=memory_store,
                user_id=self.config.get("user_id", "yuyi"),
            )
            try:
                self.memory_relevance_evaluator = MemoryRelevanceEvaluator()
            except Exception as _e:
                logger.warning(f"MemoryRelevanceEvaluator 初始化失败（已隔离）: {_e}")
                self.memory_relevance_evaluator = None
            try:
                self.memory_consolidation_engine = MemoryConsolidationEngine()
            except Exception as _e:
                logger.warning(f"MemoryConsolidationEngine 初始化失败（已隔离）: {_e}")
                self.memory_consolidation_engine = None
            self.growth_adapter = GrowthAdapter(
                proposals_path=self.config.get("growth_proposals_path"),
            )
            # Phase 3.5.7: ProposalEvaluator + PersonalityAdapter
            try:
                ev_th = EvaluationThresholds(
                    min_confidence=self.config.get("eval_min_confidence", 0.45),
                    min_evidence_count=self.config.get("eval_min_evidence_count", 2),
                    contradiction_max_delta=self.config.get("eval_contradiction_max_delta", 0.08),
                    stability_window=self.config.get("eval_stability_window", 5),
                    stability_min_ratio=self.config.get("eval_stability_min_ratio", 0.6),
                )
                self.proposal_evaluator = ProposalEvaluator(thresholds=ev_th)
            except Exception as _e:
                logger.warning(f"ProposalEvaluator 初始化失败，使用默认: {_e}")
                self.proposal_evaluator = ProposalEvaluator()
            try:
                self.personality_adapter = PersonalityAdapter(runtime_context=self)
            except Exception as _e:
                logger.warning(f"PersonalityAdapter 初始化失败: {_e}")
                self.personality_adapter = None
            try:
                # Phase 4.4.1：注入共享 GrowthState 到 adapters 路径
                self.personality_resolver = PersonalityResolver(state=self.get_growth_state())
            except Exception as _e:
                logger.warning(f"PersonalityResolver 初始化失败: {_e}")
                self.personality_resolver = None
            try:
                self.personality_evolution_pipeline = PersonalityEvolutionPipeline(
                    history_path=self.config.get("personality_evolution_history_path"),
                    block_when_identity_unstable=self.config.get("pep_block_when_identity_unstable", True),
                    auto_apply_self_model=False,
                    history_limit=int(self.config.get("pep_history_limit", 300)),
                )
            except Exception as _e:
                logger.warning(f"PersonalityEvolutionPipeline 初始化失败: {_e}")
                self.personality_evolution_pipeline = None

            # Phase 3.5.8: SelfModel 系统
            try:
                self.self_model_manager = SelfModelManager(
                    identity_id=self.config.get("self_model_identity_id")
                )
                sm_cfg = SelfModelUpdaterConfig(
                    min_preference_confidence=self.config.get("sm_min_preference_confidence", 0.3),
                    min_pattern_confidence=self.config.get("sm_min_pattern_confidence", 0.3),
                    min_pattern_frequency=self.config.get("sm_min_pattern_frequency", 1),
                    min_trait_delta_for_suggestion=self.config.get("sm_min_trait_delta", 0.002),
                    max_single_corevalue_weight_delta=self.config.get("sm_max_cv_delta", 0.05),
                    require_approval_default=self.config.get("sm_require_approval", True),
                )
                self.self_model_updater = SelfModelUpdater(config=sm_cfg)
            except Exception as _e:
                logger.warning(f"SelfModel 初始化失败（已隔离）: {_e}")
                self.self_model_manager = None
                self.self_model_updater = None

            # Phase 6.3: SelfModelAdapter + 自动 bootstrap（默认开启）
            self._init_self_model_bootstrap()

            # Phase 3.5.9: Identity Continuity Layer（默认关闭，需显式启用）
            if self._identity_continuity_enabled:
                try:
                    ct = ContinuityThresholds(
                        continuity_threshold=self.config.get("ic_continuity_threshold", 0.7),
                        trait_reversal_delta=self.config.get("ic_trait_reversal_delta", 0.08),
                        value_drop_threshold=self.config.get("ic_value_drop_threshold", 0.10),
                        identity_break_trait_count=self.config.get("ic_identity_break_trait_count", 3),
                        identity_break_trait_delta=self.config.get("ic_identity_break_trait_delta", 0.08),
                        understanding_regression_threshold=self.config.get("ic_understanding_regression_threshold", 0.05),
                    )
                    self.identity_continuity_checker = IdentityContinuityChecker(thresholds=ct)
                    self.identity_continuity_history = IdentityContinuityHistory()
                except Exception as _e:
                    logger.warning(f"IdentityContinuity 初始化失败（已隔离）: {_e}")
                    self.identity_continuity_checker = None
                    self.identity_continuity_history = None

            # Phase 3.5.17: Identity Stability Engine（默认与 continuity 同步）
            if self._identity_stability_enabled:
                try:
                    st_cfg = IdentityStabilityEngineConfig(
                        stability_threshold=float(self.config.get("identity_stability_threshold", 0.75)),
                        history_limit=int(self.config.get("identity_stability_history_limit", 200)),
                    )
                    self.identity_stability_engine = IdentityStabilityEngine(config=st_cfg)
                except Exception as _e:
                    logger.warning(f"IdentityStabilityEngine 初始化失败（已隔离）: {_e}")
                    self.identity_stability_engine = None

            # Phase 3.5.26: Personality Stability Engine（默认跟随 identity stability）
            if self._personality_stability_enabled:
                try:
                    pst_cfg = PersonalityStabilityConfig(
                        stability_threshold=float(self.config.get("personality_stability_threshold", 0.72)),
                        min_core_value_weight=float(self.config.get("personality_core_value_min_weight", 0.45)),
                        max_contradictions=int(self.config.get("personality_max_contradictions", 8)),
                        max_trait_delta=float(self.config.get("personality_max_trait_delta", 0.18)),
                    )
                    self.personality_stability_engine = PersonalityStabilityEngine(config=pst_cfg)
                except Exception as _e:
                    logger.warning(f"PersonalityStabilityEngine 初始化失败（已隔离）: {_e}")
                    self.personality_stability_engine = None

            # Phase 3.5.10: Identity Anchor System（默认关闭，需显式启用）
            if self._identity_anchor_enabled:
                try:
                    self.identity_anchor_manager = IdentityAnchorManager()
                except Exception as _e:
                    logger.warning(f"IdentityAnchor 初始化失败（已隔离）: {_e}")
                    self.identity_anchor_manager = None

            # Phase 3.5.11: Autonomous Reflection Scheduler（默认关闭）
            if self._reflection_scheduler_enabled:
                try:
                    schedule = ReflectionSchedule(
                        schedule_id=self.config.get("rs_schedule_id", "default"),
                        enabled=True,
                        triggers=[
                            ReflectionTrigger(ReflectionTriggerConfig(
                                trigger_id="event_trigger",
                                trigger_type="event_count",
                                min_event_count=int(self.config.get("rs_min_event_count", 5)),
                            )),
                            ReflectionTrigger(ReflectionTriggerConfig(
                                trigger_id="time_trigger",
                                trigger_type="time_interval",
                                interval_seconds=float(self.config.get("rs_interval_seconds", 300.0)),
                            )),
                            ReflectionTrigger(ReflectionTriggerConfig(
                                trigger_id="importance_trigger",
                                trigger_type="importance_score",
                                min_importance=float(self.config.get("rs_min_importance", 0.6)),
                            )),
                        ],
                        trigger_mode=self.config.get("rs_trigger_mode", "any"),
                        cooldown_seconds=float(self.config.get("rs_cooldown_seconds", 60.0)),
                        auto_refresh_self_model=self.config.get("rs_auto_refresh_self_model", False),
                        auto_refresh_continuity=self.config.get("rs_auto_refresh_continuity", False),
                    )
                    self.reflection_scheduler = ReflectionScheduler(schedule=schedule)
                except Exception as _e:
                    logger.warning(f"ReflectionScheduler 初始化失败（已隔离）: {_e}")
                    self.reflection_scheduler = None

            # Phase 3.5.19: Autonomous Decision Layer（默认关闭）
            if self._autonomous_decision_enabled:
                try:
                    cfg = AutonomousDecisionConfig(
                        enabled=True,
                        max_pending_proposals=int(self.config.get("adl_max_pending_proposals", 5)),
                        min_identity_stability=float(self.config.get("adl_min_identity_stability", 0.75)),
                        stability_refresh_interval_ticks=int(self.config.get("adl_stability_refresh_ticks", 30)),
                        history_limit=int(self.config.get("adl_history_limit", 300)),
                    )
                    self.autonomous_decision_layer = AutonomousDecisionLayer(config=cfg)
                except Exception as _e:
                    logger.warning(f"AutonomousDecisionLayer 初始化失败（已隔离）: {_e}")
                    self.autonomous_decision_layer = None

            # Phase 3.5.24: Autonomous Scheduler（默认关闭）
            if self._autonomous_scheduler_enabled:
                try:
                    cfg = AutonomousSchedulerConfig(
                        enabled=True,
                        history_limit=int(self.config.get("as_history_limit", 400)),
                        memory_maintenance_interval_ticks=int(self.config.get("as_memory_interval_ticks", 10)),
                        identity_check_interval_ticks=int(self.config.get("as_identity_interval_ticks", 15)),
                        growth_evaluation_interval_ticks=int(self.config.get("as_growth_eval_interval_ticks", 8)),
                        reflection_check_interval_ticks=int(self.config.get("as_reflection_interval_ticks", 1)),
                        min_memories_for_maintenance=int(self.config.get("as_min_memories_for_maintenance", 5)),
                        proposal_evaluation_batch=int(self.config.get("as_proposal_evaluation_batch", 3)),
                    )
                    self.autonomous_scheduler = AutonomousScheduler(config=cfg)
                except Exception as _e:
                    logger.warning(f"AutonomousScheduler 初始化失败（已隔离）: {_e}")
                    self.autonomous_scheduler = None

            # Phase 3.5.12: Reflection Evaluation Layer（默认关闭）
            if self._reflection_evaluator_enabled:
                try:
                    ev_cfg = EvaluatorConfig(
                        accept_threshold=float(self.config.get("ev_accept_threshold", 0.65)),
                        reject_threshold=float(self.config.get("ev_reject_threshold", 0.35)),
                        defer_evidence_threshold=int(self.config.get("ev_defer_evidence_threshold", 2)),
                        min_alignment_score=float(self.config.get("ev_min_alignment_score", 0.5)),
                        min_stability_score=float(self.config.get("ev_min_stability_score", 0.4)),
                        min_consistency_score=float(self.config.get("ev_min_consistency_score", 0.4)),
                        max_trait_delta=float(self.config.get("ev_max_trait_delta", 0.15)),
                        max_cv_delta=float(self.config.get("ev_max_cv_delta", 0.10)),
                        max_history=int(self.config.get("ev_max_history", 200)),
                    )
                    self.reflection_evaluator = ReflectionEvaluator(config=ev_cfg)
                except Exception as _e:
                    logger.warning(f"ReflectionEvaluator 初始化失败（已隔离）: {_e}")
                    self.reflection_evaluator = None

            # Phase 3.5.13: Reflection → Growth Integration Layer（默认与 evaluator 同步）
            if (
                self._reflection_growth_bridge_enabled
                and self.growth_adapter
                and self.reflection_evaluator
            ):
                try:
                    bridge_cfg = ReflectionGrowthBridgeConfig(
                        create_on_accept=self.config.get("rgb_create_on_accept", True),
                        create_on_defer=self.config.get("rgb_create_on_defer", True),
                        create_on_revisit=self.config.get("rgb_create_on_revisit", False),
                        reject_on_identity_failure=self.config.get("rgb_reject_on_identity_failure", True),
                        history_limit=int(self.config.get("rgb_history_limit", 200)),
                    )
                    self.reflection_growth_bridge = ReflectionGrowthBridge(
                        self.growth_adapter,
                        config=bridge_cfg,
                        history_path=self.config.get("reflection_growth_history_path"),
                    )
                except Exception as _e:
                    logger.warning(f"ReflectionGrowthBridge 初始化失败（已隔离）: {_e}")
                    self.reflection_growth_bridge = None

            # Phase 3.5.13: Growth Approval Layer（默认关闭）
            if self._approval_manager_enabled and self.growth_adapter:
                try:
                    self.approval_manager = ApprovalManager(
                        growth_adapter=self.growth_adapter,
                        history_path=self.config.get("approval_history_path"),
                    )
                except Exception as _e:
                    logger.warning(f"ApprovalManager 初始化失败（已隔离）: {_e}")
                    self.approval_manager = None

            # Phase 3.5.13: Runtime Lifecycle Integration（默认关闭）
            if self._lifecycle_manager_enabled:
                try:
                    self.lifecycle_manager = LifecycleManager(
                        history_path=self.config.get("lifecycle_history_path"),
                    )
                    self._register_lifecycle_modules()
                except Exception as _e:
                    logger.warning(f"LifecycleManager 初始化失败（已隔离）: {_e}")
                    self.lifecycle_manager = None

            # Phase 3.5.14: Personality Event Bus（默认关闭）
            if self._personality_event_bus_enabled:
                try:
                    self.personality_event_bus = PersonalityEventBus(
                        history_capacity=int(
                            self.config.get("peb_history_capacity", 500)
                        ),
                        persist_path=self.config.get("peb_persist_path"),
                        auto_persist=self.config.get("peb_auto_persist", False),
                    )
                except Exception as _e:
                    logger.warning(f"PersonalityEventBus 初始化失败（已隔离）: {_e}")
                    self.personality_event_bus = None

            # Phase 3.5.20: Relationship System（默认关闭）
            if self._relationship_enabled:
                try:
                    self.relationship_repository = RelationshipRepository(
                        data_dir=str(self._state_file.parent),
                        user_id=self.config.get("user_id", "yuyi"),
                    )
                    self.relationship_state_runtime = self.relationship_repository.load_state()
                    self.relationship_model_runtime = self.relationship_repository.load_relationship_model()
                    self.relationship_intelligence_engine = RelationshipIntelligenceEngine()
                except Exception as _e:
                    logger.warning(f"RelationshipSystem 初始化失败（已隔离）: {_e}")
                    self.relationship_repository = None
                    self.relationship_state_runtime = None
                    self.relationship_model_runtime = None
                    self.relationship_intelligence_engine = None

            # Phase 3.5.20: Emotion System（默认关闭）
            if self._emotion_enabled:
                try:
                    from src.emotion.emotion_repository import EmotionRepository
                    from src.emotion.emotion_trace_repository import EmotionTraceRepository
                    base_dir = self._state_file.parent
                    self.emotion_manager = EmotionManager(
                        repository=EmotionRepository(str(base_dir / "emotion_state.json")),
                        trace_repository=EmotionTraceRepository(str(base_dir / "emotion_traces.json")),
                        counter_file=str(base_dir / "emotion_analysis_counter.json"),
                    )
                    self.emotion_dynamics_engine = EmotionDynamicsEngine(self.emotion_manager)
                except Exception as _e:
                    logger.warning(f"EmotionManager 初始化失败（已隔离）: {_e}")
                    self.emotion_manager = None
                    self.emotion_dynamics_engine = None

            # Phase 3.5.20: Runtime Integration Manager（默认关闭）
            if self._runtime_integration_enabled:
                try:
                    self.runtime_integration_manager = RuntimeIntegrationManager()
                except Exception as _e:
                    logger.warning(f"RuntimeIntegrationManager 初始化失败（已隔离）: {_e}")
                    self.runtime_integration_manager = None

            # 将适配器连接到 ExperienceBuilder 和 ReflectionEngine
            if self.experience_builder:
                self.experience_builder.memory_adapter = self.memory_adapter
            if self.reflection_engine:
                self.reflection_engine.growth_adapter = self.growth_adapter
            if self.runtime_integration_manager:
                self._register_runtime_integration_modules()

        # 经验构建追踪
        self._building_experience_id: Optional[str] = None
        self._building_start_time: float = 0.0
        # Phase 3.5.12: 缓存最近一次 ReflectionInsight（供评估器使用）
        self._last_reflection_insight: Optional[Any] = None

    # ==================== 生命周期 ====================

    def _start(self) -> bool:
        """启动 RuntimeCore"""
        try:
            self._load_state()
            self._setup_scheduler()
            self._subscribe_events()
            self._last_tick = time.time()
            logger.info("RuntimeCore 启动完成")
            return True
        except Exception as e:
            logger.error(f"RuntimeCore 启动失败: {e}")
            return False

    def _stop(self) -> bool:
        """停止 RuntimeCore"""
        try:
            self._save_state()
            self.scheduler.stop()
            logger.info("RuntimeCore 已停止")
            return True
        except Exception as e:
            logger.error(f"RuntimeCore 停止失败: {e}")
            return False

    # ==================== 内部设置 ====================

    def _setup_scheduler(self) -> None:
        """设置周期任务"""
        self.scheduler.add_interval_task(
            name="tick",
            interval_seconds=self._tick_interval,
            callback=self.tick,
        )
        # 可以添加更多周期任务，如：
        # - 每小时检查反思
        # - 每天保存完整快照
        self.scheduler.start()

    def _subscribe_events(self) -> None:
        """订阅全局事件"""
        self.event_bus.subscribe_all(self._on_event)

    # ==================== 事件处理 ====================

    def _on_event(self, event: Any) -> None:
        """
        处理全局事件

        Args:
            event: YuyiEvent 或兼容对象
        """
        event_type = getattr(event, "event_type", "unknown")
        event_data = getattr(event, "data", {})

        # 记录状态快照（用于经验构建）
        self_state_before = self.self_state.to_dict()

        # 更新 self_state
        self.self_state.update_from_event(event_type, event_data)

        # 记录到 world_state
        self.world_state.add_event(event_type, event_data)

        # 更新 world_state 中的 self_state 引用
        self.world_state.self_state = self.self_state

        # 开始经验构建（Phase 3.5.5）
        if self.experience_builder:
            self._building_experience_id = self.experience_builder.start_building(
                trigger_event={"event_type": event_type, "data": event_data},
                trigger_type="event",
                self_state_before=self_state_before,
            )
            self._building_start_time = time.time()
            self._record_runtime_lifecycle_event(
                STAGE_EXPERIENCE_RECEIVED,
                source="event",
                source_id=self._building_experience_id or "",
                details={"event_type": event_type},
            )
            # 通知反思调度器（若启用）
            try:
                self.notify_scheduler_event(importance=float(event_data.get("importance", 0.0) or 0.0))
            except Exception:
                pass

        # 通知自主决策层（若启用）
        if self.autonomous_decision_layer:
            try:
                self.autonomous_decision_layer.on_event(self, importance=float(event_data.get("importance", 0.0) or 0.0))
            except Exception:
                pass

        # 触发决策
        self._maybe_decide()

    # ==================== 周期心跳 ====================

    def tick(self) -> None:
        """
        周期心跳

        由调度器定期调用，负责：
        - 状态自然衰减
        - 更新时间
        - 触发决策
        - 定期保存状态
        """
        now = time.time()
        delta = now - self._last_tick
        self._last_tick = now
        self._tick_count += 1

        # 状态自然衰减
        self.self_state.decay(delta)

        # 更新时间
        self.world_state.update_time()
        self.world_state.self_state = self.self_state

        # 触发决策
        self._maybe_decide()

        # Phase 3.5.19: Autonomous Decision Layer（可选）
        if self.autonomous_decision_layer:
            try:
                self.autonomous_decision_layer.on_tick(self)
            except Exception as e:
                logger.warning(f"AutonomousDecisionLayer tick 异常（已隔离）: {e}")

        # Phase 3.5.24: Autonomous Scheduler（可选）
        if self.autonomous_scheduler:
            try:
                self.autonomous_scheduler.on_tick(self)
            except Exception as e:
                logger.warning(f"AutonomousScheduler tick 异常（已隔离）: {e}")

        # 定期保存状态（每5分钟）
        if int(now) % 300 == 0:
            self._save_state()

    # ==================== 决策 ====================

    def _maybe_decide(self) -> None:
        """
        判断是否产生决策

        双层决策：
        1. Rule-based DecisionEngine（安全层）
        2. CognitiveEngine（认知层，可选）

        两层结果合并后分发。

        Phase 3.5.5: 分发后记录 Action 结果到 Experience。
        """
        # 层 1：规则引擎
        decisions = self.decision_engine.evaluate_all(self.world_state)
        dispatched_types: set = set()
        dispatched_actions: List[Action] = []

        for decision in decisions:
            if decision.confidence >= self._decision_confidence_threshold:
                action = Action.from_decision(decision)
                self.action_dispatcher.dispatch(action)
                dispatched_types.add(decision.action_type)
                dispatched_actions.append(action)
                self.world_state.last_action = {
                    "action_id": action.action_id,
                    "action_type": action.action_type,
                    "reason": action.reason,
                    "timestamp": time.time(),
                }
                logger.debug(f"Action dispatched (rule): {action.action_type} ({action.reason})")

        # 层 2：认知决策层（Phase 3.5.4，可选）
        if self.cognitive_engine:
            try:
                cognitive_decisions = self._run_cognitive_layer()
                for decision_intent in cognitive_decisions:
                    if decision_intent.action_type in dispatched_types:
                        # 规则引擎已处理相同类型，跳过认知层重复
                        continue
                    if decision_intent.confidence >= self._decision_confidence_threshold:
                        action = Action(
                            action_id=decision_intent.intent_id,
                            action_type=decision_intent.action_type,
                            payload=decision_intent.payload,
                            reason=decision_intent.reason,
                        )
                        self.action_dispatcher.dispatch(action)
                        dispatched_types.add(decision_intent.action_type)
                        dispatched_actions.append(action)
                        logger.debug(
                            f"Action dispatched (cognitive): {action.action_type} "
                            f"({action.reason})"
                        )
            except Exception as e:
                logger.warning(f"CognitiveEngine 决策异常（已隔离）: {e}")

        # Phase 3.5.5: 完成经验构建
        if self.experience_builder and self._building_experience_id and dispatched_actions:
            # 记录第一个 Action 的结果
            action = dispatched_actions[0]
            result = ActionResult(
                action_id=action.action_id,
                success=True,
                error_message="",
                response_received=False,
                user_response="",
                state_changes={},
                side_effects=[f"dispatched: {action.action_type}"],
            )
            self.experience_builder.record_decision(
                experience_id=self._building_experience_id,
                decision_source="rule" if action in dispatched_actions[:len(decisions)] else "cognitive",
                intention_id="",
                action_type=action.action_type,
            )
            experience = self.experience_builder.finish_building(
                experience_id=self._building_experience_id,
                result=result,
                self_state_after=self.self_state.to_dict(),
            )
            self._building_experience_id = None
            if experience:
                self._emit_domain_event(
                    EVENT_EXPERIENCE_CREATED,
                    source="experience_builder",
                    source_id=getattr(experience, "experience_id", ""),
                    payload={
                        "experience_id": getattr(experience, "experience_id", ""),
                        "action_type": getattr(experience, "action_type", ""),
                        "trigger_type": getattr(experience, "trigger_type", ""),
                    },
                )

            # Phase 3.5.6: 将经验刷新到 Memory（通过 Adapter）
            if experience and self.memory_adapter:
                try:
                    self.memory_adapter.store_experience(experience)
                    self._record_runtime_lifecycle_event(
                        STAGE_MEMORY_CREATED,
                        source="memory_adapter",
                        source_id=getattr(experience, "experience_id", ""),
                        details={
                            "action_type": getattr(experience, "action_type", ""),
                            "trigger_type": getattr(experience, "trigger_type", ""),
                        },
                    )
                    self._emit_domain_event(
                        EVENT_MEMORY_CREATED,
                        source="memory_adapter",
                        source_id=getattr(experience, "experience_id", ""),
                        payload={
                            "experience_id": getattr(experience, "experience_id", ""),
                            "action_type": getattr(experience, "action_type", ""),
                            "trigger_type": getattr(experience, "trigger_type", ""),
                        },
                    )
                except Exception as e:
                    logger.warning(f"MemoryAdapter 存储经验失败（已隔离）: {e}")

    def _run_cognitive_layer(self) -> List[Any]:
        """运行认知决策层，返回已验证的 DecisionIntent 列表"""
        if not self.cognitive_engine:
            return []

        context = DecisionContext(
            self_state=self.self_state,
            world_state=self.world_state.to_dict(),
            trigger="tick",
            recent_intentions=[
                {"action_type": a.action_type, "reason": a.reason}
                for a in self.action_dispatcher.get_history()[-5:]
            ],
            last_action_time=self.world_state.last_action.get("timestamp") if self.world_state.last_action else None,
        )

        result = self.cognitive_engine.evaluate(context)
        return result.validated_intents

    # ==================== 状态持久化 ====================

    def _load_state(self) -> None:
        """
        加载之前的状态

        从 state_file 恢复 world_state 和 self_state。
        如果文件不存在或损坏，使用默认状态。
        """
        if not self._state_file.exists():
            logger.info("RuntimeCore 状态文件不存在，使用默认状态")
            return

        try:
            with open(self._state_file, "r", encoding="utf-8") as f:
                data = json.load(f)

            self.world_state = WorldState.from_dict(data.get("world_state", {}))
            self.self_state = SelfState.from_dict(data.get("self_state", {}))
            # 同步引用
            self.world_state.self_state = self.self_state

            logger.info("RuntimeCore 状态已恢复")
        except Exception as e:
            logger.warning(f"状态恢复失败，使用默认状态: {e}")

    def _save_state(self) -> None:
        """
        保存当前状态

        将 world_state 和 self_state 写入 state_file。
        """
        try:
            self._state_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self._state_file, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "world_state": self.world_state.to_dict(),
                        "self_state": self.self_state.to_dict(),
                        "last_saved": time.time(),
                    },
                    f,
                    ensure_ascii=False,
                    indent=2,
                )
            logger.debug("RuntimeCore 状态已保存")
        except Exception as e:
            logger.error(f"状态保存失败: {e}")

    # ==================== 公共接口 ====================

    def get_snapshot(self) -> Dict[str, Any]:
        """
        获取当前运行时快照

        Returns:
            包含 world_state、self_state、last_tick 的字典
        """
        return {
            "world_state": self.world_state.to_dict(),
            "self_state": self.self_state.to_dict(),
            "last_tick": self._last_tick,
            "is_running": self.is_running,
            "runtime_lifecycle": self.get_runtime_lifecycle_state(),
            "identity_continuity": self.get_identity_continuity_report() if self.identity_continuity_history else None,
            "identity_anchor_integrity": self.get_anchor_integrity_report(use_self_model=True) if self.identity_anchor_manager else None,
            "identity_stability": self.get_identity_stability_report() if self.identity_stability_engine else None,
            "personality_stability": self.get_personality_stability_report() if self.personality_stability_engine else None,
            "autonomous_decision": self.autonomous_decision_layer.get_snapshot() if self.autonomous_decision_layer else None,
            "autonomous_scheduler": self.autonomous_scheduler.get_snapshot() if self.autonomous_scheduler else None,
            "runtime_health": self.get_runtime_health_report() if self.runtime_integration_manager else None,
            "self_reflection": self.get_self_reflection_snapshot(),
            "contradiction_report": self.get_contradiction_report(),
            "long_term_pattern_report": self.get_long_term_pattern_report(),
            "relationship_state": self.get_relationship_state_snapshot(),
            "relationship_model": self.get_relationship_model_snapshot(),
            "emotion_state": self.get_emotion_state_snapshot(),
            "emotion_dynamics": self.get_emotion_dynamics_snapshot(),
        }

    def get_self_state(self) -> SelfState:
        """获取当前自身状态"""
        return self.self_state

    def get_world_state(self) -> WorldState:
        """获取当前世界状态"""
        return self.world_state

    def inject_event(self, event_type: str, event_data: Dict[str, Any]) -> None:
        """
        手动注入事件（用于测试或外部触发）

        Args:
            event_type: 事件类型
            event_data: 事件数据
        """
        self._on_event(type("obj", (object,), {"event_type": event_type, "data": event_data})())

    def trigger_decision(self, reason: str = "manual") -> Optional[Dict[str, Any]]:
        """
        手动触发一次决策（用于测试或外部触发）

        Args:
            reason: 触发原因

        Returns:
            决策结果字典，包含 action 和 reason；若无决策则返回 None
        """
        decisions = self.decision_engine.evaluate_all(self.world_state)
        for decision in decisions:
            if decision.confidence >= self._decision_confidence_threshold:
                action = Action.from_decision(decision)
                self.action_dispatcher.dispatch(action)
                self.world_state.last_action = {
                    "action_id": action.action_id,
                    "action_type": action.action_type,
                    "reason": action.reason,
                    "timestamp": time.time(),
                }
                return {
                    "action": action,
                    "reason": decision.reason,
                    "confidence": decision.confidence,
                }
        return None

    # ==================== 公共属性 ====================

    @property
    def tick_count(self) -> int:
        """已执行的 tick 次数"""
        return self._tick_count

    @property
    def bus(self) -> RuntimeEventBus:
        """事件总线（向后兼容）"""
        return self.event_bus

    def _emit_domain_event(
        self,
        event_type: str,
        *,
        source: str,
        source_id: str = "",
        payload: Optional[Dict[str, Any]] = None,
        related_ids: Optional[List[str]] = None,
    ) -> Optional[Dict[str, Any]]:
        if not self._event_driven_enabled or not self.domain_event_bus:
            return None
        evt = self.domain_event_bus.emit(
            event_type,
            source=source,
            source_id=source_id,
            payload=payload or {},
            related_ids=related_ids or [],
            emit_legacy_aliases=True,
        )
        return evt.to_dict()

    def get_domain_event_history(self, event_type: Optional[str] = None, limit: int = 100) -> List[Dict[str, Any]]:
        if not self.domain_event_bus:
            return []
        return self.domain_event_bus.get_history(event_type=event_type, limit=limit)

    # ==================== Phase 3.5.5: 经验与反思接口 ====================

    def get_experiences(self) -> List[Any]:
        """
        获取经验缓冲区

        Returns:
            经验列表
        """
        if self.experience_builder:
            return self.experience_builder.get_buffer()
        return []

    def get_insights(self) -> List[Any]:
        """
        获取反思洞察历史

        Returns:
            洞察列表
        """
        if self.reflection_engine:
            return self.reflection_engine.get_insights()
        return []

    def get_reflection_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """获取统一反思历史（基础反思 + 自省增强层）。"""
        items: List[Dict[str, Any]] = []
        if self.reflection_engine:
            items.extend([i.to_dict() if hasattr(i, "to_dict") else dict(i) for i in self.reflection_engine.get_recent_insights(limit=limit)])
        if self.self_reflection_engine:
            items.extend(self.self_reflection_engine.get_history(limit=limit))
        items.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
        return items[:limit]

    def handle_completed_experience(self, experience: Any, *, store_to_memory: bool = True) -> Dict[str, Any]:
        """
        统一处理已完成 experience：
        - 发出 `experience_created`
        - 需要时写入 memory 并发出 `memory_created`

        用于事件驱动路径与测试/外部集成路径统一接入，
        避免只有 `_on_action_completed()` 才能走标准事件链。
        """
        result = {
            "experience_emitted": False,
            "memory_written": False,
        }
        if not experience:
            return result

        self._emit_domain_event(
            EVENT_EXPERIENCE_CREATED,
            source="experience_builder",
            source_id=getattr(experience, "experience_id", ""),
            payload={
                "experience_id": getattr(experience, "experience_id", ""),
                "action_type": getattr(experience, "action_type", ""),
                "trigger_type": getattr(experience, "trigger_type", ""),
            },
        )
        result["experience_emitted"] = True

        if store_to_memory and self.memory_adapter:
            try:
                self.memory_adapter.store_experience(experience)
                self._emit_domain_event(
                    EVENT_MEMORY_CREATED,
                    source="memory_adapter",
                    source_id=getattr(experience, "experience_id", ""),
                    payload={
                        "experience_id": getattr(experience, "experience_id", ""),
                        "action_type": getattr(experience, "action_type", ""),
                        "trigger_type": getattr(experience, "trigger_type", ""),
                    },
                )
                result["memory_written"] = True
            except Exception as e:
                logger.warning(f"handle_completed_experience 写入 memory 失败（已隔离）: {e}")
        return result

    def run_memory_consolidation(self, limit: int = 50) -> Optional[Dict[str, Any]]:
        """
        运行长期记忆巩固。

        注意：
        - 不覆盖原始记忆
        - 只生成 consolidation report
        """
        if not self.memory_adapter or not self.memory_consolidation_engine:
            return None
        try:
            memories = self.memory_adapter.get_memory_store().load() or []
            report = self.memory_consolidation_engine.consolidate(memories, limit=limit)
            return report.to_dict()
        except Exception as e:
            logger.warning(f"MemoryConsolidationEngine 执行失败（已隔离）: {e}")
            return None

    def run_self_reflection(self, limit: int = 50) -> List[Any]:
        """
        运行增强层自省，生成多条 ReflectionInsight。

        注意：
        - 不替换旧 ReflectionEngine
        - 不直接修改人格 / proposal / 记忆
        """
        if not self.self_reflection_engine or not self.experience_builder:
            return []
        try:
            experiences = self.experience_builder.get_buffer()[-limit:]
            memories: List[Dict[str, Any]] = []
            if self.memory_adapter and hasattr(self.memory_adapter, "get_memory_store"):
                memories = self.memory_adapter.get_memory_store().load()[-limit:] or []

            emotional_patterns: List[Dict[str, Any]] = []
            em_summary = self.get_emotional_memory_summary(limit=limit)
            if em_summary:
                emotional_patterns = list(em_summary.get("patterns", []) or [])
                emotional_patterns.extend(list(em_summary.get("dominant_emotions", []) or []))

            relationship_changes: List[Dict[str, Any]] = []
            if self.relationship_model_runtime:
                relationship_changes = list(self.relationship_model_runtime.trust_changes[-limit:])

            personality_changes: List[Dict[str, Any]] = []
            if self.personality_evolution_pipeline:
                personality_changes = self.personality_evolution_pipeline.get_history(limit=limit) or []

            self_model = self.get_self_model_full() if self.self_model_manager else {}
            return self.self_reflection_engine.reflect(
                memories=memories,
                experiences=experiences,
                emotional_patterns=emotional_patterns,
                relationship_changes=relationship_changes,
                personality_changes=personality_changes,
                self_model=self_model or {},
            )
        except Exception as e:
            logger.warning(f"SelfReflectionEngine 执行失败（已隔离）: {e}")
            return []

    def reflect_on_experiences(self) -> Optional[Any]:
        """
        对当前经验进行反思，并生成 GrowthProposal candidates。

        Returns:
            生成的洞察，若无则返回 None
        """
        if not self.experience_builder or not self.reflection_engine:
            return None

        experiences = self.experience_builder.get_buffer()
        if len(experiences) < self._reflection_min_experiences:
            return None

        self._record_runtime_lifecycle_event(
            STAGE_REFLECTION_STARTED,
            source="reflection_engine",
            source_id="",
            details={"experience_count": len(experiences)},
        )
        self._emit_domain_event(
            EVENT_REFLECTION_STARTED,
            source="reflection_engine",
            payload={"experience_count": len(experiences)},
        )
        base_insight = self.reflection_engine.reflect(experiences)
        self_reflection_insights = self.run_self_reflection(limit=max(self._reflection_min_experiences, 20))
        insight = base_insight or (self_reflection_insights[0] if self_reflection_insights else None)

        # Phase 3.5.12: 缓存最近一次 ReflectionInsight
        if insight:
            self._last_reflection_insight = insight
            self._emit_domain_event(
                EVENT_REFLECTION_COMPLETED,
                source="reflection_engine",
                source_id=getattr(insight, "insight_id", ""),
                payload={
                    "insight_id": getattr(insight, "insight_id", ""),
                    "summary": getattr(insight, "summary", ""),
                    "self_reflection_snapshot": self.get_self_reflection_snapshot(),
                },
            )
            try:
                if self.reflection_growth_bridge and self.reflection_evaluator:
                    evaluation = self.reflection_evaluator.evaluate_insight(insight)
                    self._record_runtime_lifecycle_event(
                        STAGE_EVALUATION_COMPLETED,
                        source="reflection_evaluator",
                        source_id=getattr(evaluation, "evaluation_id", ""),
                        details={
                            "insight_id": getattr(insight, "insight_id", ""),
                            "recommendation": getattr(evaluation, "recommendation", ""),
                            "overall_score": getattr(evaluation, "overall_score", 0.0),
                        },
                    )
                    self._emit_domain_event(
                        EVENT_EVALUATION_COMPLETED,
                        source="reflection_evaluator",
                        source_id=getattr(evaluation, "evaluation_id", ""),
                        payload={
                            "insight_id": getattr(insight, "insight_id", ""),
                            "evaluation_id": getattr(evaluation, "evaluation_id", ""),
                            "recommendation": getattr(evaluation, "recommendation", ""),
                            "overall_score": getattr(evaluation, "overall_score", 0.0),
                        },
                    )
                    identity_status = self._build_reflection_growth_identity_status()
                    bridge_record = self.reflection_growth_bridge.process(
                        insight=insight,
                        evaluation=evaluation,
                        identity_status=identity_status,
                    )
                    if getattr(bridge_record, "proposal_ids", []):
                        self._record_runtime_lifecycle_event(
                            STAGE_PROPOSAL_CREATED,
                            source="reflection_growth_bridge",
                            source_id=(bridge_record.proposal_ids[0] if bridge_record.proposal_ids else ""),
                            details={
                                "proposal_ids": list(bridge_record.proposal_ids),
                                "decision": getattr(bridge_record, "decision", ""),
                                "evaluation_id": getattr(bridge_record, "evaluation_id", ""),
                            },
                        )
                        self._emit_domain_event(
                            EVENT_PROPOSAL_CREATED,
                            source="reflection_growth_bridge",
                            source_id=(bridge_record.proposal_ids[0] if bridge_record.proposal_ids else ""),
                            payload={
                                "proposal_ids": list(bridge_record.proposal_ids),
                                "evaluation_id": getattr(bridge_record, "evaluation_id", ""),
                                "decision": getattr(bridge_record, "decision", ""),
                            },
                            related_ids=list(getattr(bridge_record, "proposal_ids", []) or []),
                        )
                elif self.growth_adapter:
                    # 向后兼容：桥接层未启用时沿用旧路径
                    self.growth_adapter.store_insight(insight)
                    proposals = self.get_growth_proposals(status="proposed", limit=10)
                    matched = [p for p in proposals if getattr(p, "source_event_id", "") == getattr(insight, "insight_id", "")]
                    if matched:
                        self._record_runtime_lifecycle_event(
                            STAGE_PROPOSAL_CREATED,
                            source="growth_adapter",
                            source_id=getattr(matched[0], "id", ""),
                            details={
                                "proposal_ids": [getattr(p, "id", "") for p in matched],
                                "compatibility_path": True,
                            },
                        )
                        self._emit_domain_event(
                            EVENT_PROPOSAL_CREATED,
                            source="growth_adapter",
                            source_id=getattr(matched[0], "id", ""),
                            payload={
                                "proposal_ids": [getattr(p, "id", "") for p in matched],
                                "compatibility_path": True,
                            },
                            related_ids=[getattr(p, "id", "") for p in matched],
                        )
            except Exception as e:
                logger.warning(f"Reflection → Growth 桥接失败，回退旧路径（已隔离）: {e}")
                if self.growth_adapter:
                    try:
                        self.growth_adapter.store_insight(insight)
                    except Exception as sub_e:
                        logger.warning(f"GrowthAdapter 存储洞察失败（已隔离）: {sub_e}")

        return insight

    # ==================== Phase 3.5.6: 适配器接口 ====================

    def get_memory_experiences(self, limit: int = 10) -> List[Any]:
        """
        从 Memory 获取经验

        Args:
            limit: 最大数量

        Returns:
            经验列表
        """
        if self.memory_adapter:
            return self.memory_adapter.get_recent_experiences(limit)
        return []

    def search_memory_experiences(
        self,
        action_type: Optional[str] = None,
        trigger_type: Optional[str] = None,
        limit: int = 10,
    ) -> List[Any]:
        """
        搜索 Memory 中的经验

        Args:
            action_type: Action 类型过滤
            trigger_type: 触发类型过滤
            limit: 最大数量

        Returns:
            经验列表
        """
        if self.memory_adapter:
            return self.memory_adapter.search_experiences(
                action_type=action_type,
                trigger_type=trigger_type,
                limit=limit,
            )
        return []

    def get_growth_proposals(
        self,
        status: Optional[str] = None,
        limit: int = 50,
    ) -> List[Any]:
        """
        获取 GrowthProposal 列表

        Args:
            status: 状态过滤
            limit: 最大数量

        Returns:
            提案列表
        """
        if self.growth_adapter:
            return self.growth_adapter.list_proposals(status=status, limit=limit)
        return []

    def accept_growth_proposal(self, proposal_id: str) -> Optional[Any]:
        """
        接受 GrowthProposal（Phase 3.5.7 更新：评估后生成 PersonalityChangeRequest）

        Args:
            proposal_id: 提案 ID

        Returns:
            更新后的提案
        """
        if not self.growth_adapter:
            return None

        accepted = self.growth_adapter.accept_proposal(proposal_id)
        if accepted is None:
            return None

        self._record_runtime_lifecycle_event(
            STAGE_PROPOSAL_APPLIED,
            source="growth_adapter",
            source_id=proposal_id,
            details={"status": getattr(accepted, "status", "")},
            force=True,
        )
        self._emit_domain_event(
            EVENT_PROPOSAL_APPLIED,
            source="growth_adapter",
            source_id=proposal_id,
            payload={"proposal_id": proposal_id, "status": getattr(accepted, "status", "")},
            related_ids=[proposal_id],
        )

        # Phase 3.5.7: 评估通过后生成 PersonalityChangeRequest
        try:
            self._process_accepted_proposal_to_change_request(accepted)
        except Exception as e:
            logger.warning(f"接受提案后生成 ChangeRequest 失败（非致命）: {e}")

        return accepted

    def reject_growth_proposal(self, proposal_id: str) -> Optional[Any]:
        """
        拒绝 GrowthProposal

        Args:
            proposal_id: 提案 ID

        Returns:
            更新后的提案
        """
        if self.growth_adapter:
            return self.growth_adapter.reject_proposal(proposal_id)
        return None

    # ============================================================
    # Phase 3.5.7: ProposalEvaluator + PersonalityAdapter 接口
    # ============================================================

    def evaluate_growth_proposal(self, proposal: Any) -> Optional[EvaluationResult]:
        """
        对 GrowthProposal 执行四维评估（confidence/evidence/contradiction/stability）

        Args:
            proposal: GrowthProposal 实例

        Returns:
            EvaluationResult，若 evaluator 未初始化返回 None
        """
        if not self.proposal_evaluator:
            return None
        # 取近期接受的提案作为历史上下文
        recent_accepted = []
        if self.growth_adapter:
            recent_accepted = self.growth_adapter.list_proposals(status="accepted", limit=10) or []
        return self.proposal_evaluator.evaluate(
            proposal,
            recent_accepted_proposals=recent_accepted,
        )

    def process_proposal_to_change_request(
        self,
        proposal: Any,
        source_insight_id: Optional[str] = None,
    ) -> Optional[PersonalityChangeRequest]:
        """
        对提案进行评估，通过后生成 PersonalityChangeRequest 并加入 pending 列表。

        注意：不会立即应用人格变更，只是生成请求供调用方审批。

        Args:
            proposal: GrowthProposal 实例
            source_insight_id: 可选，关联的反思洞察 ID

        Returns:
            PersonalityChangeRequest，评估不通过或初始化失败返回 None
        """
        if not self.personality_adapter:
            return None

        # 0. Personality Stability Gate（仅阻断向下游推进，不修改 proposal 状态）
        try:
            pst_report = self.refresh_personality_stability(force=True)
            if pst_report is not None and not bool(pst_report.get("is_stable", True)):
                logger.info(
                    f"GrowthProposal {getattr(proposal, 'id', '')} 暂不推进 ChangeRequest："
                    f"personality_stability={pst_report.get('stability_score', 0.0)}"
                )
                return None
        except Exception as e:
            logger.warning(f"人格稳定性门控失败（已隔离）: {e}")

        # 1. 评估
        eval_result = self.evaluate_growth_proposal(proposal)
        evaluator_meta: Dict[str, Any] = {}
        if eval_result is not None:
            evaluator_meta = eval_result.to_evaluator_meta()
            if not eval_result.passed:
                logger.info(
                    f"GrowthProposal {proposal.id} 评估未通过: "
                    f"score={eval_result.score:.3f} reasons={eval_result.reasons}"
                )
                return None

        # 2. 生成 ChangeRequest
        cr = self.personality_adapter.build_change_request(
            proposal,
            source_insight_id=source_insight_id,
            evaluator_meta=evaluator_meta,
        )

        # 3. 加入 pending 列表
        self._pending_change_requests.append(cr)
        if len(self._pending_change_requests) > 200:
            # 防止内存无限增长（超过 200 条丢最旧的
            self._pending_change_requests = self._pending_change_requests[-200:]
        return cr

    def list_personality_change_requests(
        self,
        limit: int = 50,
    ) -> List[PersonalityChangeRequest]:
        """
        获取 pending PersonalityChangeRequest 列表（最新在前）

        Args:
            limit: 最大条数

        Returns:
            PersonalityChangeRequest 列表（从新到旧）
        """
        pending = list(self._pending_change_requests)
        pending.reverse()
        return pending[:limit]

    def clear_personality_change_requests(self) -> int:
        """
        清空 pending PersonalityChangeRequest 列表

        Returns:
            被清理的条目数
        """
        n = len(self._pending_change_requests)
        self._pending_change_requests.clear()
        return n

    def apply_personality_change_request_in_memory(
        self,
        change_request: PersonalityChangeRequest,
    ) -> Dict[str, Any]:
        """
        对一个 PersonalityChangeRequest 执行 in-memory apply（仅测试/预览用）。

        注意：此方法不会修改任何真实人格状态或 Persona 文档。

        Args:
            change_request: PersonalityChangeRequest

        Returns:
            dict 包含 evolution_applied / growth_records / before / after
        """
        result: Dict[str, Any] = {
            "evolution_applied": False,
            "growth_records_count": 0,
            "evolution_before": {},
            "evolution_after": {},
            "note": "",
        }

        if not self.personality_adapter:
            result["note"] = "personality_adapter_not_initialized"
            return result

        # Path 1: EvolutionRecord path（仅内存）
        er = change_request.get("evolution_record")
        if er and self.personality_adapter:
            # 构造一个临时 proposal 来调用 apply_proposal
            from src.contracts.growth_schema import GrowthProposal, ChangeItem
            pcs = []
            for trait, ch in er.get("trait_changes", {}).items():
                before = ch.get("before", 0.5)
                delta = ch.get("delta", 0.0) or 0.0
                pcs.append(ChangeItem(
                    path=f"personality.traits.{trait}",
                    before=before,
                    after=round(before + delta, 4),
                    reason=f"from_change_request_{change_request.get('request_id', '')}",
                ))
            fake_proposal = GrowthProposal(
                proposed_changes=pcs,
                confidence=float(change_request.get("confidence", 0.5) or 0.5),
            )
            env = self.personality_adapter.apply_proposal(
                fake_proposal,
                actor="runtime_core_preview",
                mark_approved=True,
            )
            result["evolution_applied"] = bool(env.get("applied"))
            result["evolution_before"] = env.get("before", {})
            result["evolution_after"] = env.get("after", {})
            result["evolution_record_id"] = env.get("evolution_record_id", "")
            result["note"] = env.get("note", "")

        # Path 2: GrowthRecord（仅统计数量，实际应用由 GrowthAccumulator 外部完成）
        result["growth_records_count"] = len(change_request.get("growth_records", []) or [])
        if not result["note"]:
            result["note"] = "growth_records_pending_external_accumulator"
        else:
            result["note"] = f"{result['note']} | growth_records_pending_external_accumulator"
        return result

    # ============================================================
    # 内部：已接受提案 → PersonalityChangeRequest
    # ============================================================

    def _process_accepted_proposal_to_change_request(self, accepted_proposal: Any) -> Optional[PersonalityChangeRequest]:
        """
        在 accept_growth_proposal 成功后调用：评估并生成 PersonalityChangeRequest。
        （Phase 3.5.8 扩展：进一步生成 SelfModelChangeSuggestion，加入 pending）
        """
        cr: Optional[PersonalityChangeRequest] = None
        try:
            # evaluator_meta 里需要有 pattern_detected（从 evaluator_meta 取）
            # 从 accepted_proposal 提取 insight_id（如果有）
            evaluator_meta_existing = getattr(accepted_proposal, "evaluator_meta", None) or {}
            source_insight_id = None
            if isinstance(evaluator_meta_existing, dict):
                source_insight_id = evaluator_meta_existing.get("source_insight_id")

            cr = self.process_proposal_to_change_request(
                accepted_proposal,
                source_insight_id=source_insight_id,
            )
        except Exception as e:
            logger.warning(f"处理已接受提案失败: {e}")
            return None

        # Phase 3.5.8: 从已接受提案 + 生成的 PCR 生成 SelfModel 变化建议
        if cr is not None and self.self_model_updater is not None:
            try:
                sug = self.self_model_updater.from_pcr(cr)
                if sug is not None:
                    self._pending_self_model_suggestions.append(sug)
                    # 防止内存增长
                    if len(self._pending_self_model_suggestions) > 300:
                        self._pending_self_model_suggestions = self._pending_self_model_suggestions[-300:]
            except Exception as e2:
                logger.warning(f"PCR -> SelfModel 建议生成失败（非致命）: {e2}")
        return cr

    # ============================================================
    # Phase 3.5.8: SelfModel 公开接口
    # ============================================================

    def generate_self_model_suggestion_from_pcr(
        self,
        change_request: PersonalityChangeRequest,
    ) -> Optional[SelfModelChangeSuggestion]:
        """
        基于单个 PersonalityChangeRequest 生成 SelfModel 变化建议（纯函数，不入队）。
        """
        if not self.self_model_updater:
            return None
        try:
            return self.self_model_updater.from_pcr(dict(change_request))
        except Exception as e:
            logger.warning(f"generate_self_model_suggestion_from_pcr 失败: {e}")
            return None

    def generate_self_model_suggestion_from_insights(
        self,
        insights: List[Any],
    ) -> List[SelfModelChangeSuggestion]:
        """基于 ReflectionInsights 生成 SelfModel 建议列表（纯函数，不入队）。"""
        if not self.self_model_updater:
            return []
        try:
            return self.self_model_updater.from_insights(list(insights or []))
        except Exception as e:
            logger.warning(f"generate_self_model_suggestion_from_insights 失败: {e}")
            return []

    def list_self_model_suggestions(self, limit: int = 50) -> List[SelfModelChangeSuggestion]:
        """获取 pending SelfModel 变化建议（最新在前）。"""
        pending = list(self._pending_self_model_suggestions)
        pending.reverse()
        return pending[:limit]

    def clear_self_model_suggestions(self) -> int:
        """清空 pending SelfModel 建议，返回清理数。"""
        n = len(self._pending_self_model_suggestions)
        self._pending_self_model_suggestions.clear()
        return n

    def accept_self_model_suggestion(
        self,
        suggestion: SelfModelChangeSuggestion,
        *,
        apply_preferences: bool = True,
        apply_patterns: bool = True,
        apply_core_weights: bool = True,
        apply_stable_updates: bool = True,
        apply_history: bool = True,
        apply_understanding: bool = True,
    ) -> bool:
        """
        显式审批并应用一条 SelfModel 变化建议。

        仅更新内存中的 SelfModelManager，不修改 TraitState/Persona。
        返回 True 表示应用成功。
        """
        if not self.self_model_manager or not self.self_model_updater:
            return False
        if suggestion.requires_approval:
            pass  # 默认需要外部调用 accept 才算审批通过
        try:
            self.self_model_updater.apply_suggestion(
                manager=self.self_model_manager,
                suggestion=suggestion,
                apply_preferences=apply_preferences,
                apply_patterns=apply_patterns,
                apply_core_weights=apply_core_weights,
                apply_stable_updates=apply_stable_updates,
                apply_history=apply_history,
                apply_understanding=apply_understanding,
            )
            # 应用后从 pending 中移除（按 suggestion_id 匹配）
            target = suggestion.suggestion_id
            self._pending_self_model_suggestions = [
                s for s in self._pending_self_model_suggestions if s.suggestion_id != target
            ]
            return True
        except Exception as e:
            logger.warning(f"accept_self_model_suggestion 失败: {e}")
            return False

    def reject_self_model_suggestion(self, suggestion_id: str) -> bool:
        """显式拒绝一条 SelfModel 变化建议（从 pending 中移除）。"""
        before = len(self._pending_self_model_suggestions)
        self._pending_self_model_suggestions = [
            s for s in self._pending_self_model_suggestions if s.suggestion_id != suggestion_id
        ]
        return len(self._pending_self_model_suggestions) < before

    def refresh_self_model(
        self,
        *,
        trait_states: Optional[Dict[str, Any]] = None,
        growth_records: Optional[List[Any]] = None,
        insights: Optional[List[Any]] = None,
        personality_vector_dict: Optional[Dict[str, Any]] = None,
        relationship_state: Optional[Dict[str, Any]] = None,
    ) -> Optional[Dict[str, Any]]:
        """
        基于当前人格 / 成长 / 反思 / 关系状态刷新 SelfModel，
        返回 snapshot 字典。不修改 TraitState / Persona 文档。
        """
        if not self.self_model_manager:
            return None
        try:
            self.self_model_manager.refresh(
                trait_states=trait_states or {},
                growth_records=list(growth_records or []),
                insights=list(insights or []),
                personality_vector_dict=personality_vector_dict or {},
                relationship_state=relationship_state or {},
            )
            return self.self_model_manager.snapshot()
        except Exception as e:
            logger.warning(f"refresh_self_model 失败（已隔离）: {e}")
            return None

    def get_self_model_snapshot(self) -> Optional[Dict[str, Any]]:
        """获取最新 SelfModel snapshot（不刷新）。"""
        if not self.self_model_manager:
            return None
        return self.self_model_manager.snapshot()

    def get_self_model_full(self) -> Optional[Dict[str, Any]]:
        """获取完整 SelfIdentity 字典（持久化/调试用）。"""
        if not self.self_model_manager:
            return None
        return self.self_model_manager.get_full()

    def refresh_self_model_from_runtime(self) -> Optional[Dict[str, Any]]:
        """
        便捷方法：从 Runtime 当前已连接的 Memory / Growth / Reflection 适配器
        中读取可访问数据，生成 SelfModel snapshot。

        注：当前 Runtime 未暴露完整的 TraitState/GrowthRecord 访问接口时，
        此方法会回退到「仅 insights」模式。
        """
        if not self.self_model_manager:
            return None
        insights = self.get_insights() if hasattr(self, "get_insights") else []
        trait_states = {}
        if self.personality_resolver and hasattr(self.personality_resolver, "get_trait_states"):
            try:
                trait_states = self.personality_resolver.get_trait_states() or {}
            except Exception:
                trait_states = {}
        # Memory 中 experiences 可用于 experience_awareness 统计（这里以 insights 近似）
        return self.refresh_self_model(
            insights=insights,
            trait_states=trait_states,
            growth_records=[],
            relationship_state=self.get_relationship_state_snapshot() or {},
        )

    # ============================================================
    # Phase 3.5.9: Identity Continuity Layer 公开接口
    # ============================================================

    def refresh_identity_continuity(
        self,
        *,
        force: bool = False,
    ) -> Optional[Dict[str, Any]]:
        """
        刷新身份连续性检测：基于当前 SelfModel snapshot 生成 IdentitySnapshot，
        与上一次快照比较，生成 ContinuityReport 并存入历史。

        默认关闭（identity_continuity_enabled=False 时返回 None）。

        Args:
            force: 即使连续性未启用也强制执行（用于测试）

        Returns:
            ContinuityReport.to_dict()，若未启用或无前置快照返回 None
        """
        if not self._identity_continuity_enabled and not force:
            return None
        if not self.identity_continuity_checker or not self.self_model_manager:
            return None

        # 1. 生成当前 SelfModel snapshot → IdentitySnapshot
        sm_snap = self.self_model_manager.snapshot()
        current_snap = IdentitySnapshot.from_self_model_snapshot(
            sm_snap,
            identity_id=self.self_model_manager.identity.identity_id,
        )

        # 2. 存入历史
        if self.identity_continuity_history:
            self.identity_continuity_history.add_snapshot(current_snap)

        # 3. 如果有前置快照，生成报告
        if self._last_identity_snapshot is not None:
            report = self.identity_continuity_checker.generate_change_report(
                before=self._last_identity_snapshot,
                after=current_snap,
            )
            if self.identity_continuity_history:
                self.identity_continuity_history.add_report(report)
            # 更新 last snapshot
            self._last_identity_snapshot = current_snap
            return report.to_dict()
        else:
            # 首次：无前置快照，仅记录当前快照
            self._last_identity_snapshot = current_snap
            return {
                "report_id": None,
                "note": "first_snapshot_no_comparison",
                "snapshot_id": current_snap.snapshot_id,
                "version": current_snap.version,
            }

    def get_identity_continuity_report(self) -> Optional[Dict[str, Any]]:
        """
        获取最新的 Identity Continuity Report。

        Returns:
            最新 ContinuityReport.to_dict()，若无返回 None
        """
        if not self.identity_continuity_history:
            return None
        report = self.identity_continuity_history.get_latest_report()
        if report is None:
            return None
        return report.to_dict()

    def list_identity_continuity_reports(self, limit: int = 20) -> List[Dict[str, Any]]:
        """获取最近的 ContinuityReport 列表（最新在前）。"""
        if not self.identity_continuity_history:
            return []
        reports = self.identity_continuity_history.get_reports(limit=limit)
        return [r.to_dict() for r in reports]

    def get_identity_continuity_average(self, window: int = 10) -> float:
        """获取最近 N 次报告的平均连续性分数。"""
        if not self.identity_continuity_history:
            return 1.0
        return self.identity_continuity_history.get_average_continuity(window=window)

    def has_identity_break_detected(self) -> bool:
        """是否检测到过身份断裂。"""
        if not self.identity_continuity_history:
            return False
        return self.identity_continuity_history.has_break_detected()

    def get_identity_snapshot(self) -> Optional[Dict[str, Any]]:
        """获取最新的 IdentitySnapshot 字典。"""
        if not self.identity_continuity_history:
            return None
        snap = self.identity_continuity_history.get_latest_snapshot()
        if snap is None:
            return None
        return snap.to_dict()

    def capture_identity_snapshot(
        self,
        *,
        from_self_model: bool = True,
        snapshot_data: Optional[Dict[str, Any]] = None,
    ) -> Optional[IdentitySnapshot]:
        """
        手动捕获一个 IdentitySnapshot（不入历史比较，仅记录）。

        用于测试或外部流程需要显式记录某个时间点的身份状态。
        """
        if not self.identity_continuity_checker:
            return None
        if from_self_model and self.self_model_manager:
            sm_snap = self.self_model_manager.snapshot()
            snap = IdentitySnapshot.from_self_model_snapshot(
                sm_snap,
                identity_id=self.self_model_manager.identity.identity_id,
            )
        elif snapshot_data:
            snap = IdentitySnapshot.from_self_model_snapshot(snapshot_data)
        else:
            return None
        if self.identity_continuity_history:
            self.identity_continuity_history.add_snapshot(snap)
        return snap

    def compare_identity_snapshots(
        self,
        before: IdentitySnapshot,
        after: IdentitySnapshot,
    ) -> Optional[Dict[str, Any]]:
        """
        比较两个 IdentitySnapshot，生成 ContinuityReport（不入历史）。
        纯函数式，用于测试或外部调用。
        """
        if not self.identity_continuity_checker:
            return None
        report = self.identity_continuity_checker.generate_change_report(before, after)
        return report.to_dict()

    # ============================================================
    # Phase 3.5.17: Identity Stability Engine 公开接口
    # ============================================================

    def refresh_identity_stability(self, *, force: bool = False) -> Optional[Dict[str, Any]]:
        """
        生成并记录 IdentityStabilityReport。

        信号输入：
        - ContinuityReport（若 continuity 可用）
        - AnchorIntegrityReport（若 anchor 可用）
        - 记忆污染检测（读取 MemoryStore 最近记忆，不删除，只报告）
        """
        if not self._identity_stability_enabled and not force:
            return None
        if not self.identity_stability_engine or not self.self_model_manager:
            return None

        # 1) continuity
        cont = None
        if self.identity_continuity_checker and self.identity_continuity_history:
            _ = self.refresh_identity_continuity(force=True)
            latest = self.get_identity_continuity_report()
            if latest:
                cont = latest

        # 2) anchor integrity
        anchor_report = self.get_anchor_integrity_report(use_self_model=True) if self.identity_anchor_manager else None

        # 3) recent memories (best-effort)
        memories: List[Dict[str, Any]] = []
        try:
            store = None
            if self.memory_adapter:
                store = self.memory_adapter.get_memory_store()
            else:
                memory_store_path = self.config.get("memory_store_path")
                if memory_store_path:
                    from src.memory.memory_store import MemoryStore
                    store = MemoryStore(memory_store_path)
            if store:
                all_mem = store.load() or []
                memories = all_mem[-300:]
        except Exception as e:
            logger.warning(f"读取记忆用于稳定性检测失败（已隔离）: {e}")
            memories = []

        report = self.identity_stability_engine.generate_report(
            identity_id=self.self_model_manager.identity.identity_id,
            continuity_report=cont,
            anchor_integrity_report=anchor_report,
            memories=memories,
        )
        self._emit_domain_event(
            EVENT_IDENTITY_CHANGED,
            source="identity_stability_engine",
            source_id=report.report_id,
            payload={
                "report_id": report.report_id,
                "stability_score": report.stability_score,
                "is_stable": report.is_stable,
                "identity_id": report.identity_id,
            },
            related_ids=[report.report_id],
        )
        return report.to_dict()

    def get_identity_stability_report(self) -> Optional[Dict[str, Any]]:
        if not self.identity_stability_engine:
            return None
        latest = self.identity_stability_engine.history.get_latest_report()
        return latest.to_dict() if latest else None

    def list_identity_stability_reports(self, limit: int = 20) -> List[Dict[str, Any]]:
        if not self.identity_stability_engine:
            return []
        reports = self.identity_stability_engine.history.get_reports(limit=limit)
        return [r.to_dict() for r in reports]

    def get_identity_stability_snapshot(self) -> Optional[Dict[str, Any]]:
        if not self.identity_stability_engine:
            return None
        return self.identity_stability_engine.history.get_snapshot().to_dict()

    # ============================================================
    # Phase 3.5.26: Personality Stability Engine 公开接口
    # ============================================================

    def refresh_personality_stability(self, *, force: bool = False) -> Optional[Dict[str, Any]]:
        """
        生成并记录 PersonalityStabilityReport。

        输入：
        - SelfModel full/snapshot
        - 最近 evolution history
        - IdentityStabilityReport
        - TraitState snapshot（若 personality_resolver 可用）
        """
        if not self._personality_stability_enabled and not force:
            return None
        if not self.personality_stability_engine or not self.self_model_manager:
            return None

        identity_report = self.get_identity_stability_report()
        if identity_report is None and self.identity_stability_engine:
            identity_report = self.refresh_identity_stability(force=True)

        trait_states: Dict[str, Any] = {}
        if self.personality_resolver and hasattr(self.personality_resolver, "get_trait_states"):
            try:
                trait_states = self.personality_resolver.get_trait_states() or {}
            except Exception:
                trait_states = {}

        evolution_history: List[Dict[str, Any]] = []
        if self.personality_evolution_pipeline:
            try:
                evolution_history = self.personality_evolution_pipeline.get_history(limit=20) or []
            except Exception:
                evolution_history = []

        report = self.personality_stability_engine.generate_report(
            identity_id=self.self_model_manager.identity.identity_id,
            self_model_full=self.get_self_model_full() or {},
            self_model_snapshot=self.get_self_model_snapshot() or {},
            trait_states=trait_states,
            evolution_history=evolution_history,
            identity_stability_report=identity_report or {},
        )
        return report.to_dict()

    def get_personality_stability_report(self) -> Optional[Dict[str, Any]]:
        if not self.personality_stability_engine:
            return None
        history = self.personality_stability_engine.get_history(limit=1)
        return history[0] if history else None

    def list_personality_stability_reports(self, limit: int = 20) -> List[Dict[str, Any]]:
        if not self.personality_stability_engine:
            return []
        return self.personality_stability_engine.get_history(limit=limit)

    # ============================================================
    # Phase 3.5.10: Identity Anchor System 公开接口
    # ============================================================

    def get_identity_anchor(self, anchor_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        获取身份锚点。

        Args:
            anchor_id: 指定锚点 ID，返回单个锚点；None 返回所有锚点的摘要

        Returns:
            单个锚点 dict 或所有锚点列表 dict
        """
        if not self.identity_anchor_manager:
            return None
        if anchor_id:
            a = self.identity_anchor_manager.get_anchor(anchor_id)
            return a.to_dict() if a else None
        return {
            "anchors": [a.to_dict() for a in self.identity_anchor_manager.get_all_anchors()],
            "total": len(self.identity_anchor_manager.anchors),
            "core_count": len(self.identity_anchor_manager.get_core_anchors()),
        }

    def refresh_identity_anchor(self) -> Optional[Dict[str, Any]]:
        """
        刷新身份锚点：生成当前锚点快照。

        如果 SelfModel 可用，会将 SelfModel 版本关联到快照中。
        不修改任何 Persona / TraitState 数据。

        Returns:
            AnchorSnapshot.to_dict()，若未启用返回 None
        """
        if not self.identity_anchor_manager:
            return None
        sm_version = 0
        if self.self_model_manager:
            sm_version = self.self_model_manager.identity.version
        snap = self.identity_anchor_manager.create_anchor_snapshot(
            self_model_version=sm_version
        )
        return snap.to_dict()

    def get_anchor_integrity_report(
        self,
        *,
        use_self_model: bool = True,
        threshold: float = 0.8,
    ) -> Optional[Dict[str, Any]]:
        """
        获取锚点完整性报告。

        检测锚点权重偏移、约束违反、核心锚点缺失、SelfModel 一致性。

        Args:
            use_self_model: 是否将当前 SelfModel snapshot 作为参考
            threshold: 完整性阈值（默认 0.8）

        Returns:
            AnchorIntegrityReport.to_dict()，若未启用返回 None
        """
        if not self.identity_anchor_manager:
            return None
        sm_snap = None
        if use_self_model and self.self_model_manager:
            sm_snap = self.self_model_manager.snapshot()
        report = self.identity_anchor_manager.validate_anchor_integrity(
            self_model_snapshot=sm_snap,
            threshold=threshold,
        )
        return report.to_dict()

    def get_anchor_snapshot(self) -> Optional[Dict[str, Any]]:
        """获取最新的锚点快照。"""
        if not self.identity_anchor_manager:
            return None
        snap = self.identity_anchor_manager.get_latest_snapshot()
        return snap.to_dict() if snap else None

    def list_anchor_snapshots(self, limit: int = 20) -> List[Dict[str, Any]]:
        """获取最近的锚点快照列表（最新在前）。"""
        if not self.identity_anchor_manager:
            return []
        snaps = self.identity_anchor_manager.get_snapshots(limit=limit)
        return [s.to_dict() for s in snaps]

    def apply_anchor_change_proposal(
        self,
        proposal: AnchorChangeProposal,
    ) -> bool:
        """
        审批并应用锚点变化建议。

        要求 proposal.approved = True（外部显式审批）。
        不自动审批，不修改 Persona / TraitState。
        """
        if not self.identity_anchor_manager:
            return False
        return self.identity_anchor_manager.apply_change_proposal(proposal)

    def get_anchor_manager_state(self) -> Optional[Dict[str, Any]]:
        """获取锚点管理器完整状态（调试用）。"""
        if not self.identity_anchor_manager:
            return None
        return self.identity_anchor_manager.to_dict()

    # ============================================================
    # Phase 3.5.11: Autonomous Reflection Scheduler 公开接口
    # ============================================================

    def schedule_reflection(
        self,
        trigger_type: str = "manual",
        trigger_reason: str = "",
        force: bool = True,
    ) -> Optional[Dict[str, Any]]:
        """
        手动调度一次反思。

        执行完整链路：
        reflect_on_experiences → store_insight → store_growth_proposal
        → refresh_self_model（可选）→ refresh_identity_continuity（可选）

        不自动接受 GrowthProposal（仍需人工审批）。
        不调用 LLM。

        Args:
            trigger_type: 触发类型标记
            trigger_reason: 触发原因
            force: 是否跳过冷却检查

        Returns:
            ReflectionTaskRecord.to_dict()，若调度器未启用返回 None
        """
        if not self.reflection_scheduler:
            return None

        def _do_reflection() -> Dict[str, Any]:
            """反思回调：执行完整链路"""
            result: Dict[str, Any] = {
                "insight_id": "",
                "proposal_ids": [],
                "experience_count": 0,
                "self_model_updated": False,
                "continuity_checked": False,
            }

            # 1. 反思
            insight = self.reflect_on_experiences()
            if insight:
                result["insight_id"] = getattr(insight, "insight_id", "") or (
                    insight.get("insight_id", "") if isinstance(insight, dict) else ""
                )

            # 2. 获取 buffer 中的经验数
            if self.experience_builder:
                buffer = self.experience_builder.get_buffer()
                result["experience_count"] = len(buffer) if buffer else 0

            # 3. 获取当前 proposed 状态的 proposals
            proposals = self.get_growth_proposals(status="proposed", limit=50)
            result["proposal_ids"] = [p.id for p in proposals] if proposals else []
            result["proposal_count"] = len(result["proposal_ids"])

            # 4. 可选：刷新 SelfModel
            if self.reflection_scheduler.schedule.auto_refresh_self_model:
                self.refresh_self_model_from_runtime()
                result["self_model_updated"] = True

            # 5. 可选：刷新 IdentityContinuity
            if self.reflection_scheduler.schedule.auto_refresh_continuity:
                self.refresh_identity_continuity(force=True)
                result["continuity_checked"] = True

            return result

        task = self.reflection_scheduler.run_reflection(
            reflection_callback=_do_reflection,
            trigger_type=trigger_type,
            trigger_reason=trigger_reason,
            force=force,
        )
        return task.to_dict()

    def check_reflection_trigger(self) -> Optional[Dict[str, Any]]:
        """
        检查反思触发条件（不执行反思）。

        Returns:
            {
                "should_trigger": bool,
                "reason": str,
                "trigger_results": [...],
                "snapshot": SchedulerSnapshot.to_dict(),
            }
            若调度器未启用返回 None
        """
        if not self.reflection_scheduler:
            return None
        should, reason, matched = self.reflection_scheduler.should_trigger()
        results = self.reflection_scheduler.check_triggers()
        snap = self.reflection_scheduler.get_snapshot()
        return {
            "should_trigger": should,
            "reason": reason,
            "matched_trigger": matched.to_dict() if matched else None,
            "trigger_results": [r.to_dict() for r in results],
            "snapshot": snap.to_dict(),
        }

    def run_scheduled_reflection(self) -> Optional[Dict[str, Any]]:
        """
        自动检查触发条件并执行反思（若满足条件）。

        不自动接受 GrowthProposal。
        如果不满足触发条件，返回 skipped 状态。

        Returns:
            ReflectionTaskRecord.to_dict()，若调度器未启用返回 None
        """
        if not self.reflection_scheduler:
            return None
        should, reason, matched = self.reflection_scheduler.should_trigger()
        if not should:
            # 仍记录一条 skipped
            task = self.reflection_scheduler.run_reflection(
                reflection_callback=lambda: {"skipped": True},
                trigger_type="auto_check",
                trigger_reason=reason,
                force=False,
            )
            return task.to_dict()

        trigger_type = matched.trigger_type if matched else "auto"
        return self.schedule_reflection(
            trigger_type=trigger_type,
            trigger_reason=reason,
            force=False,
        )

    def get_scheduler_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """获取调度器执行历史（最新在前）。"""
        if not self.reflection_scheduler:
            return []
        tasks = self.reflection_scheduler.get_history(limit=limit)
        return [t.to_dict() for t in tasks]

    def get_scheduler_snapshot(self) -> Optional[Dict[str, Any]]:
        """获取调度器快照。"""
        if not self.reflection_scheduler:
            return None
        snap = self.reflection_scheduler.get_snapshot()
        return snap.to_dict()

    def notify_scheduler_event(self, importance: float = 0.0) -> None:
        """
        通知调度器一个事件发生（更新事件计数和重要度）。

        应在 inject_event 或 experience_builder.finish_building 后调用。
        """
        if self.reflection_scheduler:
            self.reflection_scheduler.on_event(importance=importance)

    def clear_scheduler_history(self) -> int:
        """清空调度器历史，返回清理数。"""
        if not self.reflection_scheduler:
            return 0
        return self.reflection_scheduler.clear_history()

    # ============================================================
    # Phase 3.5.19: Autonomous Decision Layer 公开接口
    # ============================================================

    def get_autonomous_decision_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        if not self.autonomous_decision_layer:
            return []
        return self.autonomous_decision_layer.get_history(limit=limit)

    def get_autonomous_decision_snapshot(self) -> Optional[Dict[str, Any]]:
        if not self.autonomous_decision_layer:
            return None
        return self.autonomous_decision_layer.get_snapshot()

    def clear_autonomous_decision_history(self) -> int:
        if not self.autonomous_decision_layer:
            return 0
        return self.autonomous_decision_layer.clear_history()

    # ============================================================
    # Phase 3.5.24: Autonomous Scheduler 公开接口
    # ============================================================

    def get_autonomous_scheduler_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        if not self.autonomous_scheduler:
            return []
        return self.autonomous_scheduler.get_history(limit=limit)

    def get_autonomous_scheduler_snapshot(self) -> Optional[Dict[str, Any]]:
        if not self.autonomous_scheduler:
            return None
        return self.autonomous_scheduler.get_snapshot()

    # ==================== Phase 3.5.12: Reflection Evaluation Layer ====================

    def evaluate_reflection(
        self,
        source_type: str,
        source: Any = None,
        *,
        source_id: Optional[str] = None,
        report: Optional[Any] = None,
    ) -> Optional[Dict[str, Any]]:
        """
        评估反思产物的价值。

        输入来源：
        - reflection_insight: 评估最近一次 ReflectionInsight（source 可为 None，自动获取）
        - growth_record: 评估指定的 GrowthRecord
        - identity_change: 评估指定的 IdentityChange（可附带 ContinuityReport）
        - relationship: 评估当前 RelationshipState（自动获取）

        输出：ReflectionEvaluation.to_dict()
        - recommendation: accept / reject / defer / revisit
        - overall_score: 0~1
        - risk_flags: 风险标记列表

        约束：不自动接受 GrowthProposal，仅产出评估意见。
        """
        if not self.reflection_evaluator:
            return None

        try:
            if source_type == SOURCE_REFLECTION_INSIGHT:
                # 默认评估最近一次反思结果
                if source is None:
                    source = self.get_last_reflection_insight()
                if source is None:
                    return None
                evaluation = self.reflection_evaluator.evaluate_insight(source)

            elif source_type == SOURCE_GROWTH_RECORD:
                if source is None:
                    return None
                evaluation = self.reflection_evaluator.evaluate_growth_record(source)

            elif source_type == SOURCE_IDENTITY_CHANGE:
                if source is None:
                    return None
                evaluation = self.reflection_evaluator.evaluate_identity_change(source, report)

            elif source_type == SOURCE_RELATIONSHIP:
                # 默认获取当前关系状态
                if source is None:
                    source = self.get_relationship_state_snapshot()
                if source is None:
                    return None
                evaluation = self.reflection_evaluator.evaluate_relationship(source)

            else:
                logger.warning(f"未知评估来源类型: {source_type}")
                return None

            return evaluation.to_dict()
        except Exception as e:
            logger.error(f"evaluate_reflection 失败: {e}")
            return None

    def _record_runtime_lifecycle_event(
        self,
        event_name: str,
        *,
        source: str = "runtime",
        source_id: str = "",
        details: Optional[Dict[str, Any]] = None,
        force: bool = False,
    ) -> Optional[RuntimeLifecycleEvent]:
        """记录认知生命周期事件。"""
        if not self.lifecycle_orchestrator:
            return None
        return self.lifecycle_orchestrator.record_event(
            event_name,
            source=source,
            source_id=source_id,
            details=details or {},
            force=force,
        )

    def get_runtime_lifecycle_state(self) -> Dict[str, Any]:
        """获取认知生命周期状态机快照。"""
        return self.lifecycle_orchestrator.get_state().to_dict()

    def get_runtime_lifecycle_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """获取认知生命周期事件历史（最新在前）。"""
        return [item.to_dict() for item in self.lifecycle_orchestrator.get_history(limit=limit)]

    def clear_runtime_lifecycle_history(self) -> int:
        """清空认知生命周期历史。"""
        return self.lifecycle_orchestrator.clear_history()

    def evaluate_last_insight(self) -> Optional[Dict[str, Any]]:
        """评估最近一次 ReflectionInsight（便捷方法）。"""
        return self.evaluate_reflection(SOURCE_REFLECTION_INSIGHT)

    def get_evaluation_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """获取评估历史（最新在前，用于审计）。"""
        if not self.reflection_evaluator:
            return []
        return [e.to_dict() for e in self.reflection_evaluator.get_history(limit=limit)]

    def get_latest_evaluation(self) -> Optional[Dict[str, Any]]:
        """获取最近一次完整评估结果。"""
        if not self.reflection_evaluator:
            return None
        ev = self.reflection_evaluator.get_latest_evaluation()
        return ev.to_dict() if ev else None

    def get_evaluation_snapshot(self) -> Optional[Dict[str, Any]]:
        """获取评估器快照。"""
        if not self.reflection_evaluator:
            return None
        return self.reflection_evaluator.get_snapshot().to_dict()

    def clear_evaluation_history(self) -> int:
        """清空评估历史，返回清理数。"""
        if not self.reflection_evaluator:
            return 0
        return self.reflection_evaluator.clear_history()

    # ==================== Phase 3.5.13: Reflection → Growth Bridge ====================

    def _build_reflection_growth_identity_status(self) -> Dict[str, Any]:
        """收集桥接层所需的身份状态。"""
        identity_status: Dict[str, Any] = {}

        continuity_report = self.get_identity_continuity_report()
        if continuity_report:
            identity_status["continuity_report"] = continuity_report

        anchor_report = self.get_anchor_integrity_report(use_self_model=True)
        if anchor_report:
            identity_status["anchor_integrity"] = anchor_report

        if continuity_report or anchor_report:
            continuity_ok = continuity_report.get("is_continuous", True) if continuity_report else True
            anchor_ok = anchor_report.get("is_intact", True) if anchor_report else True
            identity_status["identity_ok"] = continuity_ok and anchor_ok
            if not continuity_ok:
                identity_status["reason"] = "continuity check blocked proposal generation"
            elif not anchor_ok:
                identity_status["reason"] = "identity anchor integrity blocked proposal generation"
            else:
                identity_status["reason"] = "identity checks passed"
        else:
            identity_status["identity_ok"] = True
            identity_status["reason"] = "identity checks unavailable, using neutral status"

        return identity_status

    def bridge_last_reflection_to_growth(self) -> Optional[Dict[str, Any]]:
        """将最近一次 ReflectionInsight 显式桥接到 Growth。"""
        if not self.reflection_growth_bridge or not self.reflection_evaluator:
            return None
        insight = self.get_last_reflection_insight()
        if insight is None:
            return None
        evaluation = self.reflection_evaluator.evaluate_insight(insight)
        record = self.reflection_growth_bridge.process(
            insight=insight,
            evaluation=evaluation,
            identity_status=self._build_reflection_growth_identity_status(),
        )
        return record.to_dict()

    def get_reflection_growth_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """获取 Reflection → Growth 桥接历史（最新在前）。"""
        if not self.reflection_growth_bridge:
            return []
        return [item.to_dict() for item in self.reflection_growth_bridge.get_history(limit=limit)]

    def get_latest_reflection_growth_record(self) -> Optional[Dict[str, Any]]:
        """获取最近一次桥接记录。"""
        if not self.reflection_growth_bridge:
            return None
        record = self.reflection_growth_bridge.get_latest_record()
        return record.to_dict() if record else None

    def get_reflection_growth_snapshot(self) -> Optional[Dict[str, Any]]:
        """获取桥接层快照。"""
        if not self.reflection_growth_bridge:
            return None
        return self.reflection_growth_bridge.get_snapshot().to_dict()

    def clear_reflection_growth_history(self) -> int:
        """清空桥接层历史。"""
        if not self.reflection_growth_bridge:
            return 0
        return self.reflection_growth_bridge.clear_history()

    def get_last_reflection_insight(self) -> Optional[Any]:
        """获取最近一次 ReflectionInsight（供评估使用）。"""
        return self._last_reflection_insight

    def get_self_reflection_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        if not self.self_reflection_engine:
            return []
        return self.self_reflection_engine.get_history(limit=limit)

    def get_self_reflection_snapshot(self) -> Optional[Dict[str, Any]]:
        if not self.self_reflection_engine:
            return None
        return self.self_reflection_engine.get_snapshot()

    def get_contradiction_report(self) -> Optional[Dict[str, Any]]:
        if not self.self_reflection_engine:
            return None
        return self.self_reflection_engine.get_contradiction_report()

    def get_long_term_pattern_report(self) -> Optional[Dict[str, Any]]:
        if not self.self_reflection_engine:
            return None
        return self.self_reflection_engine.get_long_term_pattern_report()

    def generate_learning_goals(self, limit: int = 8) -> List[Dict[str, Any]]:
        """
        运行好奇心层，只生成 LearningGoal。

        注意：
        - 不直接写知识
        - 不直接修改人格
        """
        if not self.curiosity_engine:
            return []
        memories: List[Dict[str, Any]] = []
        if self.memory_adapter and hasattr(self.memory_adapter, "get_memory_store"):
            try:
                memories = self.memory_adapter.get_memory_store().load()[-50:] or []
            except Exception:
                memories = []
        reflection_history = self.get_self_reflection_history(limit=20) or self.get_reflection_history(limit=20)
        contradiction_report = self.get_contradiction_report() or {}
        self_model = self.get_self_model_full() if self.self_model_manager else {}
        goals = self.curiosity_engine.generate_goals(
            memories=memories,
            reflection_history=reflection_history,
            contradiction_report=contradiction_report,
            self_model=self_model or {},
        )
        return [g.to_dict() for g in goals[:limit]]

    def get_learning_goal_history(self, limit: int = 20) -> List[Dict[str, Any]]:
        if not self.curiosity_engine:
            return []
        return self.curiosity_engine.get_history(limit=limit)

    def get_curiosity_snapshot(self) -> Optional[Dict[str, Any]]:
        if not self.curiosity_engine:
            return None
        return self.curiosity_engine.get_snapshot()

    def generate_creative_directions(self, limit: int = 8) -> List[Dict[str, Any]]:
        """
        运行创造层，只生成 CreativeDirection。

        注意：
        - 不直接修改人格
        - 不直接生成 proposal
        - 不直接写入记忆
        """
        if not self.creative_engine:
            return []
        memories: List[Dict[str, Any]] = []
        if self.memory_adapter and hasattr(self.memory_adapter, "get_memory_store"):
            try:
                memories = self.memory_adapter.get_memory_store().load()[-50:] or []
            except Exception:
                memories = []
        emotional_snapshot = self.get_emotion_dynamics_snapshot() or {}
        emotional_summary = self.get_emotional_memory_summary(limit=50) or {}
        emotional_patterns = list(emotional_summary.get("patterns", []) or [])
        if not emotional_patterns:
            emotional_patterns = list(emotional_summary.get("dominant_emotions", []) or [])
        self_model = self.get_self_model_full() if self.self_model_manager else {}
        learning_goals = self.get_learning_goal_history(limit=8)
        if not learning_goals and self.curiosity_engine:
            learning_goals = self.generate_learning_goals(limit=8)
        directions = self.creative_engine.generate_directions(
            memories=memories,
            emotional_snapshot=emotional_snapshot,
            emotional_patterns=emotional_patterns,
            self_model=self_model or {},
            learning_goals=learning_goals or [],
        )
        return [d.to_dict() for d in directions[:limit]]

    def get_creative_direction_history(self, limit: int = 20) -> List[Dict[str, Any]]:
        if not self.creative_engine:
            return []
        return self.creative_engine.get_history(limit=limit)

    def get_creativity_snapshot(self) -> Optional[Dict[str, Any]]:
        if not self.creative_engine:
            return None
        return self.creative_engine.get_snapshot()

    def get_relationship_state_snapshot(self) -> Optional[Any]:
        """获取当前关系状态快照（供评估使用）。"""
        if self.relationship_state_runtime:
            return self.relationship_state_runtime.to_dict()
        return None

    def get_relationship_model_snapshot(self) -> Optional[Dict[str, Any]]:
        """获取当前关系模型快照。"""
        if self.relationship_model_runtime:
            return self.relationship_model_runtime.get_snapshot()
        return None

    def record_relationship_interaction(
        self,
        *,
        user_message: str,
        evidence_id: str = "",
        emotion_tag: str = "",
    ) -> Optional[Dict[str, Any]]:
        """
        记录一次关系互动，更新 RelationshipState + RelationshipModel。

        仅更新关系系统，不影响人格审批边界。
        """
        if (
            not self.relationship_intelligence_engine
            or not self.relationship_repository
            or not self.relationship_state_runtime
            or not self.relationship_model_runtime
        ):
            return None
        try:
            result = self.relationship_intelligence_engine.process_interaction(
                state=self.relationship_state_runtime,
                model=self.relationship_model_runtime,
                user_message=user_message,
                evidence_id=evidence_id,
                emotion_tag=emotion_tag,
            )
            self.relationship_repository.save_state(self.relationship_state_runtime)
            self.relationship_repository.save_relationship_model(self.relationship_model_runtime)
            self.notify_relationship_changed({
                "reason": "interaction_recorded",
                "interaction": result.get("interaction"),
                "trust_change": result.get("trust_change"),
                "milestones": result.get("milestones", []),
            })
            return result
        except Exception as e:
            logger.warning(f"record_relationship_interaction 失败（已隔离）: {e}")
            return None

    def get_emotion_manager(self) -> Optional["EmotionManager"]:
        """
        获取 EmotionManager 权威实例（Phase 4.2.1 Emotion Authority）。

        - 若 _emotion_enabled=True，则返回已创建的 self.emotion_manager
        - 若 _emotion_enabled=False（默认），则 lazy 创建一个基础 EmotionManager
          （不创建 EmotionDynamicsEngine），作为 Orchestrator 的权威来源
        - 创建失败返回 None，调用方需自行 fallback

        设计意图：让 RuntimeCore 成为 EmotionManager 的唯一持有者，
        Orchestrator 不再主动创建 EmotionManager，而是通过 RuntimeBridge 获取引用。
        """
        if self.emotion_manager is not None:
            return self.emotion_manager

        # Lazy 创建基础 EmotionManager（不依赖 _emotion_enabled 开关）
        try:
            from src.emotion.emotion_manager import EmotionManager as _EmotionManager
            logger.info("RuntimeCore: lazy 创建基础 EmotionManager（Emotion Authority）")
            self.emotion_manager = _EmotionManager()
            return self.emotion_manager
        except Exception as _e:
            logger.warning(f"RuntimeCore: EmotionManager lazy 创建失败: {_e}")
            return None

    def get_self_model_store(self) -> Optional["SelfModelStore"]:
        """
        获取 SelfModelStore 权威实例（Phase 4.2.2 SelfModel Authority）。

        - 若 adapters_enabled=True 且 PersonalityResolver 已创建，则返回其内部的 self_model_store
        - 否则 lazy 创建一个基础 SelfModelStore，作为 Orchestrator 的权威来源
        - 创建失败返回 None，调用方需自行 fallback

        设计意图：让 RuntimeCore 成为 SelfModelStore 的唯一持有者，
        Orchestrator 不再主动创建 SelfModelStore，而是通过 RuntimeBridge 获取引用。
        这解决了 Orchestrator 内部双 Store 分裂导致【自我认知参考】为空的问题。
        """
        # 优先使用 PersonalityResolver 内部的 SelfModelStore（若已创建）
        if self.personality_resolver is not None and hasattr(self.personality_resolver, "self_model_store"):
            return self.personality_resolver.self_model_store

        # Lazy 创建基础 SelfModelStore（不依赖 adapters_enabled 开关）
        try:
            from src.personality.self_model_store import SelfModelStore as _SelfModelStore
            if not hasattr(self, "_lazy_self_model_store") or self._lazy_self_model_store is None:
                logger.info("RuntimeCore: lazy 创建基础 SelfModelStore（SelfModel Authority）")
                self._lazy_self_model_store = _SelfModelStore()
            return self._lazy_self_model_store
        except Exception as _e:
            logger.warning(f"RuntimeCore: SelfModelStore lazy 创建失败: {_e}")
            return None

    # ============================================================
    # Phase 6.3: SelfModelAdapter + Bootstrap 公共访问
    # ============================================================

    def _init_self_model_bootstrap(self) -> None:
        """
        Phase 6.3: 默认开启 SelfModelAdapter + 自动 bootstrap。

        行为契约：
        - 任何异常（Persistence 路径不存在、JSONL 损坏、权限错误）均被隔离
        - 即使全部失败，Runtime 仍可继续运行
        - 若 adapters_enabled=False，仅当 self_model_manager 已创建时才启用
        """
        try:
            # 1) 创建 SelfModelAdapter
            try:
                from src.personality.self_model_adapter import SelfModelAdapter
                self._self_model_adapter = SelfModelAdapter(
                    self_model_manager=self.self_model_manager,
                    self_model_updater=self.self_model_updater,
                    actor="runtime_core",
                )
            except Exception as e:
                logger.warning(f"RuntimeCore: SelfModelAdapter 创建失败（已隔离）: {e}")
                self._self_model_adapter = None
                return

            # 2) 创建 SelfModelBootstrap
            try:
                from src.runtime.self_model_bootstrap import SelfModelBootstrap
                data_dir = self.config.get("self_model_data_dir", "data/self_model")
                self._self_model_bootstrap = SelfModelBootstrap(data_dir=data_dir)
            except Exception as e:
                logger.warning(f"RuntimeCore: SelfModelBootstrap 创建失败（已隔离）: {e}")
                self._self_model_bootstrap = None
                return

            # 3) 自动 attach persistence + load_state（失败隔离）
            try:
                self._self_model_bootstrap_envelope = self._self_model_bootstrap.bootstrap(
                    self._self_model_adapter
                )
                counts = self._self_model_bootstrap_envelope.get("load_counts", {})
                logger.info(
                    f"RuntimeCore: SelfModel bootstrap 完成 "
                    f"beliefs={counts.get('beliefs', 0)}, "
                    f"history={counts.get('history', 0)}, "
                    f"reflections={counts.get('reflections', 0)}"
                )
            except Exception as e:
                # 即便 wrapper 抛错也不应阻塞 Runtime
                logger.warning(f"RuntimeCore: SelfModel bootstrap 异常（已隔离）: {e}")
                self._self_model_bootstrap_envelope = {
                    "persistence_attached": False,
                    "load_counts": {"beliefs": 0, "history": 0, "reflections": 0},
                    "errors": [f"bootstrap_exception: {e}"],
                }
        except Exception as e:
            # 终极隔离：不能因 Phase 6.3 异常影响 Runtime
            logger.warning(f"RuntimeCore: _init_self_model_bootstrap 终极异常: {e}")
            self._self_model_adapter = None
            self._self_model_bootstrap = None
            self._self_model_bootstrap_envelope = {
                "errors": [f"ultimate_exception: {e}"]
            }

    def get_self_model_adapter(self) -> Any:
        """Phase 6.3: 获取共享 SelfModelAdapter（RuntimeCore 是唯一权威来源）。"""
        return self._self_model_adapter

    def get_self_model_bootstrap(self) -> Any:
        """Phase 6.3: 获取 SelfModelBootstrap 状态查看器。"""
        return self._self_model_bootstrap

    def get_self_model_bootstrap_envelope(self) -> Dict[str, Any]:
        """Phase 6.3: 获取最近一次 bootstrap 摘要（审计/调试用）。"""
        return dict(self._self_model_bootstrap_envelope or {})

    def save_self_model_state(self) -> Dict[str, Any]:
        """Phase 6.3: 显式保存 SelfModel 状态（失败隔离）。"""
        if self._self_model_bootstrap is None or self._self_model_adapter is None:
            return {"ok": False, "errors": ["bootstrap or adapter is None"]}
        try:
            ok = self._self_model_bootstrap.save(self._self_model_adapter)
            return {
                "ok": bool(ok),
                "last_save_result": self._self_model_bootstrap.last_save_result,
            }
        except Exception as e:
            logger.warning(f"RuntimeCore.save_self_model_state 失败: {e}")
            return {"ok": False, "errors": [str(e)]}

    def get_personality_resolver(self) -> Optional["PersonalityResolver"]:
        """
        获取 PersonalityResolver 权威实例（Phase 4.2.3 Personality Authority）。

        - 若 adapters_enabled=True 且已创建，返回已有实例
        - 否则 lazy 创建一个基础 PersonalityResolver
        - 注入共享的 SelfModelStore，确保人格解析与自我认知数据一致
        - 创建失败返回 None，调用方需自行 fallback

        设计意图：让 RuntimeCore 成为 PersonalityResolver 的唯一持有者，
        Orchestrator 不再主动创建 PersonalityResolver，而是通过 RuntimeBridge 获取引用。
        这解决了 Orchestrator 与 RuntimeCore（当 adapters_enabled=True 时）之间的状态分裂问题。
        """
        # 优先使用已创建的 PersonalityResolver（adapters_enabled=True 时）
        if self.personality_resolver is not None:
            return self.personality_resolver

        # Lazy 创建基础 PersonalityResolver（不依赖 adapters_enabled 开关）
        try:
            from src.personality.personality_resolver import PersonalityResolver as _Resolver
            if not hasattr(self, "_lazy_personality_resolver") or self._lazy_personality_resolver is None:
                logger.info("RuntimeCore: lazy 创建基础 PersonalityResolver（Personality Authority）")

                # Phase 4.4.1：注入共享 GrowthState，确保 PersonalityResolver 与 GrowthEngine 使用同一实例
                shared_gs = self.get_growth_state()
                self._lazy_personality_resolver = _Resolver(state=shared_gs)

                # 关键修复：确保 lazy 创建的 PersonalityResolver 内部使用的是共享的 SelfModelStore
                # （通过 get_self_model_store() 获取 Phase 4.2.2 建立的权威实例）
                shared_store = self.get_self_model_store()
                if shared_store and hasattr(self._lazy_personality_resolver, "self_model_store"):
                    self._lazy_personality_resolver.self_model_store = shared_store

            return self._lazy_personality_resolver
        except Exception as _e:
            logger.warning(f"RuntimeCore: PersonalityResolver lazy 创建失败: {_e}")
            return None

    # ==================== Memory Authority（Phase 4.3.1） ====================

    def get_memory_store(self) -> Optional["MemoryStore"]:
        """
        获取 MemoryStore 权威实例（Phase 4.3.1 Memory Authority）。

        - 若 adapters_enabled=True 且 MemoryAdapter 已创建，返回其内部的 MemoryStore
        - 否则 lazy 创建一个基础 MemoryStore（默认路径 data/memory.json）
        - 缓存唯一实例，多次调用返回同一对象
        - 创建失败返回 None，调用方需自行 fallback

        设计意图：让 RuntimeCore 成为 MemoryStore 的唯一持有者，
        Orchestrator 不再主动创建 MemoryStore，而是通过 RuntimeBridge 获取引用。
        这解决了多实例 MemoryStore 并发写入导致数据覆盖和分裂的风险。
        """
        # 优先使用 adapters_enabled=True 时已创建的 MemoryAdapter 的 store
        if hasattr(self, "memory_adapter") and self.memory_adapter is not None:
            adapter_store = getattr(self.memory_adapter, "get_memory_store", lambda: None)()
            if adapter_store is not None:
                return adapter_store

        # Lazy 创建基础 MemoryStore（不依赖 adapters_enabled 开关）
        try:
            from src.memory.memory_store import MemoryStore as _MemoryStore
            if not hasattr(self, "_lazy_memory_store") or self._lazy_memory_store is None:
                logger.info("RuntimeCore: lazy 创建基础 MemoryStore（Memory Authority）")
                self._lazy_memory_store = _MemoryStore()
            return self._lazy_memory_store
        except Exception as _e:
            logger.warning(f"RuntimeCore: MemoryStore lazy 创建失败: {_e}")
            return None

    # ==================== VectorMemory Authority（Phase 4.3.2） ====================

    def get_vector_memory(self) -> Optional["VectorMemory"]:
        """
        获取 VectorMemory 权威实例（Phase 4.3.2 VectorMemory Authority）。

        - Lazy 创建：首次调用时才初始化 ChromaDB + embedding 模型
        - 缓存唯一实例到 _lazy_vector_memory，后续调用返回同一对象
        - 创建失败返回 None，调用方需自行 fallback
        - 不影响 RuntimeCore 启动（捕获所有异常）

        设计意图：让 RuntimeCore 成为 VectorMemory 的唯一持有者，
        Orchestrator、ContextManager 等模块不再各自创建 VectorMemory，
        而是通过 RuntimeBridge 获取共享引用。
        这解决了多实例重复加载 embedding 模型（~200MB）导致的资源浪费，
        以及多个 ChromaDB PersistentClient 并发访问的锁冲突问题。
        """
        if hasattr(self, "_lazy_vector_memory") and self._lazy_vector_memory is not None:
            return self._lazy_vector_memory

        try:
            from src.memory.vector import VectorMemory as _VectorMemory
            logger.info("RuntimeCore: lazy 创建 VectorMemory（VectorMemory Authority）")
            self._lazy_vector_memory = _VectorMemory()
            return self._lazy_vector_memory
        except Exception as _e:
            logger.warning(f"RuntimeCore: VectorMemory lazy 创建失败: {_e}")
            return None

    # ==================== GrowthState Authority（Phase 4.3.3） ====================

    def get_growth_state(self) -> Optional["GrowthState"]:
        """
        获取 GrowthState 权威实例（Phase 4.3.3 GrowthState Authority）。

        - Lazy 创建：首次调用时才加载 data/growth_state.json
        - 缓存唯一实例到 _lazy_growth_state，后续调用返回同一对象
        - 创建失败返回 None，调用方需自行 fallback
        - 不影响 RuntimeCore 启动（捕获所有异常）

        设计意图：让 RuntimeCore 成为 GrowthState 的唯一持有者，
        GrowthEngine、PersonalityResolver 等模块不再各自创建 GrowthState，
        而是通过 RuntimeBridge 获取共享引用。
        这解决了多实例内存状态不同步和数据覆盖风险。
        """
        if hasattr(self, "_lazy_growth_state") and self._lazy_growth_state is not None:
            return self._lazy_growth_state

        try:
            from src.growth.growth_state import GrowthState as _GrowthState
            logger.info("RuntimeCore: lazy 创建 GrowthState（GrowthState Authority）")
            self._lazy_growth_state = _GrowthState()
            return self._lazy_growth_state
        except Exception as _e:
            logger.warning(f"RuntimeCore: GrowthState lazy 创建失败: {_e}")
            return None

    def get_emotion_state_snapshot(self) -> Optional[Any]:
        """获取当前情绪状态快照。"""
        if self.emotion_manager:
            return self.emotion_manager.state.to_dict()
        return None

    def get_emotion_dynamics_snapshot(self) -> Optional[Dict[str, Any]]:
        """获取情绪动态快照。"""
        if self.emotion_dynamics_engine:
            return self.emotion_dynamics_engine.get_snapshot()
        return None

    def get_emotion_transition_history(self, limit: int = 20) -> List[Dict[str, Any]]:
        if not self.emotion_dynamics_engine:
            return []
        return self.emotion_dynamics_engine.get_transition_history(limit=limit)

    def get_emotional_memory_summary(self, limit: int = 200) -> Optional[Dict[str, Any]]:
        if not self.emotion_dynamics_engine:
            return None
        return self.emotion_dynamics_engine.get_emotional_memory_summary(limit=limit)

    def record_emotion_event(
        self,
        *,
        event_type: str,
        intensity: float = 0.5,
        description: str = "",
        source: str = "interaction",
        memory_id: str = "",
    ) -> Optional[Dict[str, Any]]:
        """
        记录一次情绪事件，更新 EmotionState + EmotionDynamics。
        """
        if not self.emotion_manager or not self.emotion_dynamics_engine:
            return None
        try:
            event = EmotionEvent(
                event_type=event_type,
                intensity=float(intensity),
                description=description,
                source=source,
            )
            result = self.emotion_dynamics_engine.process_event(event, memory_id=memory_id or None)
            self.notify_emotion_changed({
                "reason": "emotion_event_recorded",
                "event_type": event_type,
                "transition": result.get("transition"),
                "context": result.get("context"),
            })
            return result
        except Exception as e:
            logger.warning(f"record_emotion_event 失败（已隔离）: {e}")
            return None

    def notify_emotion_changed(self, payload: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        state = self.get_emotion_state_snapshot() or {}
        dynamics = self.get_emotion_dynamics_snapshot() or {}
        return self._emit_domain_event(
            EVENT_EMOTION_CHANGED,
            source="emotion_system",
            payload={"state": state, "dynamics": dynamics, **dict(payload or {})},
        )

    def notify_relationship_changed(self, payload: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        state = self.get_relationship_state_snapshot() or {}
        model = self.get_relationship_model_snapshot() or {}
        return self._emit_domain_event(
            EVENT_RELATIONSHIP_CHANGED,
            source="relationship_system",
            payload={"state": state, "model": model, **dict(payload or {})},
        )

    # ==================== Phase 3.5.20: Runtime Final Integration ====================

    def _register_runtime_integration_modules(self) -> None:
        """向 RuntimeIntegrationManager 注册运行时子系统。"""
        if not self.runtime_integration_manager:
            return
        rim = self.runtime_integration_manager

        rim.register_module(
            name="memory_adapter",
            category="memory",
            enabled=self.memory_adapter is not None,
            metadata={"kind": "adapter"},
            health_fn=lambda: {
                "healthy": self.memory_adapter is not None,
                "memory_store_connected": self.memory_adapter is not None,
            },
        )
        rim.register_module(
            name="memory_relevance_evaluator",
            category="memory",
            enabled=self.memory_relevance_evaluator is not None,
            dependencies=["memory_adapter"],
            metadata={"kind": "evaluator"},
            health_fn=lambda: {
                "healthy": self.memory_relevance_evaluator is not None,
                "relevance_snapshot": self.memory_relevance_evaluator.get_snapshot().to_dict()
                if self.memory_relevance_evaluator else None,
            },
        )
        rim.register_module(
            name="memory_consolidation_engine",
            category="memory",
            enabled=self.memory_consolidation_engine is not None,
            dependencies=["memory_adapter", "memory_relevance_evaluator"],
            metadata={"kind": "consolidation"},
            health_fn=lambda: {
                "healthy": self.memory_consolidation_engine is not None,
                "snapshot": self.memory_consolidation_engine.get_snapshot()
                if self.memory_consolidation_engine else None,
            },
        )
        rim.register_module(
            name="experience_builder",
            category="reflection",
            enabled=self.experience_builder is not None,
            dependencies=["memory_adapter"],
            health_fn=lambda: {"healthy": self.experience_builder is not None},
        )
        rim.register_module(
            name="reflection_engine",
            category="reflection",
            enabled=self.reflection_engine is not None,
            dependencies=["experience_builder"],
            health_fn=lambda: {"healthy": self.reflection_engine is not None},
        )
        rim.register_module(
            name="self_reflection_engine",
            category="reflection",
            enabled=self.self_reflection_engine is not None,
            dependencies=["reflection_engine", "memory_consolidation_engine", "emotion_system", "relationship_system", "self_model_manager"],
            health_fn=lambda: {
                "healthy": self.self_reflection_engine is not None,
                "snapshot": self.get_self_reflection_snapshot(),
            },
        )
        rim.register_module(
            name="reflection_evaluator",
            category="reflection",
            enabled=self.reflection_evaluator is not None,
            dependencies=["reflection_engine", "self_reflection_engine"],
            health_fn=lambda: {
                "healthy": self.reflection_evaluator is not None,
                "latest_evaluation": self.get_latest_evaluation(),
            },
        )
        rim.register_module(
            name="reflection_growth_bridge",
            category="growth",
            enabled=self.reflection_growth_bridge is not None,
            dependencies=["reflection_evaluator"],
            health_fn=lambda: {
                "healthy": self.reflection_growth_bridge is not None,
                "snapshot": self.get_reflection_growth_snapshot(),
            },
        )
        rim.register_module(
            name="growth_adapter",
            category="growth",
            enabled=self.growth_adapter is not None,
            dependencies=["reflection_growth_bridge"],
            health_fn=lambda: {
                "healthy": self.growth_adapter is not None,
                "pending_proposals": len(self.get_growth_proposals(status="proposed", limit=100) or []) if self.growth_adapter else 0,
            },
        )
        rim.register_module(
            name="approval_manager",
            category="growth",
            enabled=self.approval_manager is not None,
            dependencies=["growth_adapter"],
            health_fn=lambda: {
                "healthy": self.approval_manager is not None,
                "approval_snapshot": self.get_approval_snapshot(),
            },
        )
        rim.register_module(
            name="identity_stability_engine",
            category="identity",
            enabled=self.identity_stability_engine is not None,
            dependencies=["self_model"],
            health_fn=lambda: {
                "healthy": self.identity_stability_engine is not None,
                "stability_snapshot": self.get_identity_stability_snapshot(),
            },
        )
        rim.register_module(
            name="personality_stability_engine",
            category="personality",
            enabled=self.personality_stability_engine is not None,
            dependencies=["self_model_manager", "identity_stability_engine"],
            health_fn=lambda: {
                "healthy": self.personality_stability_engine is not None,
                "latest_report": self.get_personality_stability_report(),
            },
        )
        rim.register_module(
            name="self_model_manager",
            category="personality",
            enabled=self.self_model_manager is not None,
            dependencies=["growth_adapter"],
            health_fn=lambda: {
                "healthy": self.self_model_manager is not None,
                "snapshot": self.self_model_manager.snapshot() if self.self_model_manager else None,
            },
        )
        rim.register_module(
            name="personality_evolution_pipeline",
            category="personality",
            enabled=self.personality_evolution_pipeline is not None,
            dependencies=["approval_manager", "identity_stability_engine"],
            health_fn=lambda: {
                "healthy": self.personality_evolution_pipeline is not None,
                "snapshot": self.personality_evolution_pipeline.get_snapshot()
                if self.personality_evolution_pipeline else None,
            },
        )
        rim.register_module(
            name="relationship_system",
            category="relationship",
            enabled=self.relationship_repository is not None,
            health_fn=lambda: {
                "healthy": self.relationship_repository is not None,
                "has_state": self.relationship_state_runtime is not None,
                "has_model": self.relationship_model_runtime is not None,
                "model_snapshot": self.get_relationship_model_snapshot(),
            },
        )
        rim.register_module(
            name="emotion_system",
            category="emotion",
            enabled=self.emotion_manager is not None,
            health_fn=lambda: {
                "healthy": self.emotion_manager is not None,
                "state": self.get_emotion_state_snapshot(),
                "dynamics": self.get_emotion_dynamics_snapshot(),
            },
        )
        rim.register_module(
            name="autonomous_decision_layer",
            category="autonomous",
            enabled=self.autonomous_decision_layer is not None,
            dependencies=["identity_stability_engine", "reflection_scheduler"],
            health_fn=lambda: {
                "healthy": self.autonomous_decision_layer is not None,
                "snapshot": self.get_autonomous_decision_snapshot(),
            },
        )
        rim.register_module(
            name="autonomous_scheduler",
            category="autonomous",
            enabled=self.autonomous_scheduler is not None,
            dependencies=["memory_adapter", "reflection_scheduler", "identity_stability_engine"],
            health_fn=lambda: {
                "healthy": self.autonomous_scheduler is not None,
                "snapshot": self.get_autonomous_scheduler_snapshot(),
            },
        )

    def get_runtime_health_report(self) -> Optional[Dict[str, Any]]:
        if not self.runtime_integration_manager:
            return None
        return self.runtime_integration_manager.build_health_report().to_dict()

    # ==================== Phase 3.5.13: Growth Approval Layer ====================

    def approve_growth_proposal(
        self,
        proposal_id: str,
        reason: str = "",
        actor: str = "human",
    ) -> Optional[Dict[str, Any]]:
        """
        批准 GrowthProposal（人工审批）。

        约束：
        - 不自动批准，必须显式调用
        - 生成完整审计记录
        - 不直接修改 Personality System

        Returns:
            ApprovalRecord.to_dict()，若管理器未启用或提案不存在返回 None
        """
        if not self.approval_manager:
            return None
        record = self.approval_manager.approve_proposal(
            proposal_id=proposal_id,
            reason=reason,
            actor=actor,
        )
        return record.to_dict() if record else None

    def reject_growth_proposal(
        self,
        proposal_id: str,
        reason: str = "",
        actor: str = "human",
    ) -> Optional[Dict[str, Any]]:
        """
        拒绝 GrowthProposal（人工审批）。

        Returns:
            ApprovalRecord.to_dict()，若管理器未启用或提案不存在返回 None
        """
        if not self.approval_manager:
            return None
        record = self.approval_manager.reject_proposal(
            proposal_id=proposal_id,
            reason=reason,
            actor=actor,
        )
        return record.to_dict() if record else None

    def modify_growth_proposal(
        self,
        proposal_id: str,
        changes: List[Dict[str, Any]],
        reason: str = "",
        actor: str = "human",
    ) -> Optional[Dict[str, Any]]:
        """
        修改 GrowthProposal 后批准（人工审批）。

        Args:
            proposal_id: 提案 ID
            changes: 修改项列表，每项含 path 和 after
            reason: 修改原因
            actor: 操作者

        Returns:
            ApprovalRecord.to_dict()，若管理器未启用或提案不存在返回 None
        """
        if not self.approval_manager:
            return None
        record = self.approval_manager.modify_proposal(
            proposal_id=proposal_id,
            changes=changes,
            reason=reason,
            actor=actor,
        )
        return record.to_dict() if record else None

    def get_pending_growth_proposals(self, limit: int = 50) -> List[Dict[str, Any]]:
        """获取待审批的 GrowthProposal（status='proposed'）。"""
        if not self.approval_manager:
            return []
        proposals = self.approval_manager.get_pending_proposals(limit=limit)
        return [p.to_dict() for p in proposals]

    def get_growth_approval_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """获取审批历史（最新在前，用于审计）。"""
        if not self.approval_manager:
            return []
        records = self.approval_manager.get_approval_history(limit=limit)
        return [r.to_dict() for r in records]

    def get_proposal_approval_history(self, proposal_id: str) -> List[Dict[str, Any]]:
        """获取指定提案的审批历史。"""
        if not self.approval_manager:
            return []
        records = self.approval_manager.get_proposal_history(proposal_id)
        return [r.to_dict() for r in records]

    def get_approval_snapshot(self) -> Optional[Dict[str, Any]]:
        """获取审批管理器快照。"""
        if not self.approval_manager:
            return None
        return self.approval_manager.get_snapshot().to_dict()

    def clear_approval_history(self) -> int:
        """清空审批历史，返回清理数。"""
        if not self.approval_manager:
            return 0
        return self.approval_manager.clear_history()

    # ==================== Phase 3.5.13: Runtime Lifecycle Integration ====================

    def _register_lifecycle_modules(self) -> None:
        """
        向 LifecycleManager 注册所有子系统。

        依赖关系（启动顺序）：
        Memory → ExperienceBuilder → ReflectionEngine → GrowthAdapter
        → SelfModel → Identity → ReflectionScheduler → ReflectionEvaluator
        → ReflectionGrowthBridge
        → ApprovalManager
        """
        if not self.lifecycle_manager:
            return

        lm = self.lifecycle_manager

        # Memory（基础层）
        lm.register_module(
            name="memory",
            obj=self.memory_adapter,
            save_fn=lambda: True,  # MemoryAdapter 自动持久化
            health_fn=lambda: {"healthy": self.memory_adapter is not None},
            required=True,
        )

        # MemoryRelevanceEvaluator
        lm.register_module(
            name="memory_relevance_evaluator",
            obj=self.memory_relevance_evaluator,
            dependencies=["memory"],
            health_fn=lambda: {"healthy": self.memory_relevance_evaluator is not None},
        )
        lm.register_module(
            name="memory_consolidation_engine",
            obj=self.memory_consolidation_engine,
            dependencies=["memory", "memory_relevance_evaluator"],
            health_fn=lambda: {"healthy": self.memory_consolidation_engine is not None},
        )

        # ExperienceBuilder
        lm.register_module(
            name="experience_builder",
            obj=self.experience_builder,
            dependencies=["memory", "memory_relevance_evaluator", "memory_consolidation_engine"],
            health_fn=lambda: {"healthy": self.experience_builder is not None},
        )

        # ReflectionEngine
        lm.register_module(
            name="reflection_engine",
            obj=self.reflection_engine,
            dependencies=["experience_builder"],
            health_fn=lambda: {"healthy": self.reflection_engine is not None},
        )
        lm.register_module(
            name="self_reflection_engine",
            obj=self.self_reflection_engine,
            dependencies=["reflection_engine", "self_model", "relationship", "emotion"],
            health_fn=lambda: {"healthy": self.self_reflection_engine is not None},
        )

        # GrowthAdapter
        lm.register_module(
            name="growth_adapter",
            obj=self.growth_adapter,
            dependencies=["reflection_engine", "self_reflection_engine"],
            save_fn=lambda: True,  # GrowthAdapter 自动持久化
            health_fn=lambda: {"healthy": self.growth_adapter is not None},
        )

        # SelfModel
        lm.register_module(
            name="self_model",
            obj=self.self_model_manager,
            dependencies=["growth_adapter"],
            health_fn=lambda: {"healthy": self.self_model_manager is not None},
        )
        lm.register_module(
            name="personality_stability",
            obj=self.personality_stability_engine,
            dependencies=["self_model", "identity"],
            health_fn=lambda: {"healthy": self.personality_stability_engine is not None},
        )

        # Relationship
        lm.register_module(
            name="relationship",
            obj=self.relationship_repository,
            dependencies=["memory"],
            health_fn=lambda: {
                "healthy": self.relationship_repository is not None,
                "has_model": self.relationship_model_runtime is not None,
            },
        )

        # Emotion
        lm.register_module(
            name="emotion",
            obj=self.emotion_manager,
            dependencies=["memory"],
            health_fn=lambda: {
                "healthy": self.emotion_manager is not None,
                "has_dynamics": self.emotion_dynamics_engine is not None,
            },
        )

        # Identity（Anchor + Continuity + Stability）
        lm.register_module(
            name="identity",
            obj=self.identity_stability_engine or self.identity_anchor_manager or self.identity_continuity_checker,
            dependencies=["self_model", "relationship", "emotion"],
            health_fn=lambda: {
                "healthy": (
                    self.identity_stability_engine is not None
                    or self.identity_anchor_manager is not None
                    or self.identity_continuity_checker is not None
                )
            },
        )

        # ReflectionScheduler
        lm.register_module(
            name="reflection_scheduler",
            obj=self.reflection_scheduler,
            dependencies=["identity"],
            health_fn=lambda: {"healthy": self.reflection_scheduler is not None},
        )

        # ReflectionEvaluator
        lm.register_module(
            name="reflection_evaluator",
            obj=self.reflection_evaluator,
            dependencies=["reflection_scheduler"],
            health_fn=lambda: {"healthy": self.reflection_evaluator is not None},
        )

        # ReflectionGrowthBridge
        lm.register_module(
            name="reflection_growth_bridge",
            obj=self.reflection_growth_bridge,
            dependencies=["reflection_evaluator"],
            save_fn=lambda: True,
            health_fn=lambda: {"healthy": self.reflection_growth_bridge is not None},
        )

        # ApprovalManager
        lm.register_module(
            name="approval_manager",
            obj=self.approval_manager,
            dependencies=["reflection_growth_bridge"],
            save_fn=lambda: True,  # ApprovalManager 自动持久化
            health_fn=lambda: {"healthy": self.approval_manager is not None},
        )

        # Personality Evolution Pipeline
        lm.register_module(
            name="personality_evolution_pipeline",
            obj=self.personality_evolution_pipeline,
            dependencies=["approval_manager", "identity"],
            save_fn=lambda: True,
            health_fn=lambda: {"healthy": self.personality_evolution_pipeline is not None},
        )

        # Autonomous Decision Layer
        lm.register_module(
            name="autonomous_decision_layer",
            obj=self.autonomous_decision_layer,
            dependencies=["identity", "reflection_scheduler"],
            health_fn=lambda: {"healthy": self.autonomous_decision_layer is not None},
        )
        lm.register_module(
            name="autonomous_scheduler",
            obj=self.autonomous_scheduler,
            dependencies=["memory", "reflection_scheduler", "identity"],
            health_fn=lambda: {"healthy": self.autonomous_scheduler is not None},
        )

    def start_lifecycle(self) -> Optional[Dict[str, Any]]:
        """
        启动完整生命周期。

        按依赖顺序启动所有子系统，生成审计记录。
        """
        if not self.lifecycle_manager:
            return None
        record = self.lifecycle_manager.start_all()
        return record.to_dict()

    def resume_lifecycle(self) -> Optional[Dict[str, Any]]:
        """
        从持久化状态恢复生命周期。

        先加载各模块状态，再启动。
        """
        if not self.lifecycle_manager:
            return None
        record = self.lifecycle_manager.resume_all()
        return record.to_dict()

    def save_lifecycle(self) -> Optional[Dict[str, Any]]:
        """
        保存所有模块状态。

        按依赖逆序保存，生成审计记录。
        """
        if not self.lifecycle_manager:
            return None
        # 先保存 RuntimeCore 自身状态
        try:
            self._save_state()
        except Exception as e:
            logger.warning(f"RuntimeCore 状态保存失败: {e}")
        record = self.lifecycle_manager.save_all()
        return record.to_dict()

    def stop_lifecycle(self) -> Optional[Dict[str, Any]]:
        """
        停止完整生命周期。

        先尝试保存状态，再按依赖逆序停止所有模块。
        """
        if not self.lifecycle_manager:
            return None
        record = self.lifecycle_manager.stop_all()
        return record.to_dict()

    def get_lifecycle_snapshot(self) -> Optional[Dict[str, Any]]:
        """获取生命周期完整快照。"""
        if not self.lifecycle_manager:
            return None
        return self.lifecycle_manager.get_snapshot().to_dict()

    def get_lifecycle_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """获取生命周期历史（最新在前，用于审计）。"""
        if not self.lifecycle_manager:
            return []
        records = self.lifecycle_manager.get_history(limit=limit)
        return [r.to_dict() for r in records]

    def get_lifecycle_current_phase(self) -> str:
        """获取当前生命周期阶段。"""
        if not self.lifecycle_manager:
            return PHASE_INIT
        return self.lifecycle_manager.get_current_phase()

    def health_check_lifecycle(self) -> Dict[str, Any]:
        """对所有生命周期管理的模块执行健康检查。"""
        if not self.lifecycle_manager:
            return {"total": 0, "healthy": 0, "degraded": 0, "error": 0, "modules": {}}
        return self.lifecycle_manager.health_check_all()

    def clear_lifecycle_history(self) -> int:
        """清空生命周期历史，返回清理数。"""
        if not self.lifecycle_manager:
            return 0
        return self.lifecycle_manager.clear_history()

    def get_module_lifecycle_status(self, name: str) -> Optional[Dict[str, Any]]:
        """获取指定模块的生命周期状态。"""
        if not self.lifecycle_manager:
            return None
        status = self.lifecycle_manager.get_module_status(name)
        return status.to_dict() if status else None

    # ==================== Phase 3.5.14: Personality Event Bus ====================

    def publish_personality_event(self, event: PersonalityEvent) -> bool:
        """发布人格事件。"""
        if not self.personality_event_bus:
            return False
        return self.personality_event_bus.publish(event)

    def publish_memory_event(
        self,
        event_type: str,
        source: str,
        payload: Optional[Dict[str, Any]] = None,
        related_ids: Optional[List[str]] = None,
        severity: str = "info",
        actor: str = "",
    ) -> Optional[Dict[str, Any]]:
        """便捷发布 Memory 事件。"""
        if not self.personality_event_bus:
            return None
        event = self.personality_event_bus.publish_memory_event(
            event_type=event_type,
            source=source,
            payload=payload,
            related_ids=related_ids,
            severity=severity,
            actor=actor,
        )
        return event.to_dict()

    def publish_growth_event(
        self,
        event_type: str,
        source: str,
        payload: Optional[Dict[str, Any]] = None,
        related_ids: Optional[List[str]] = None,
        severity: str = "info",
        actor: str = "",
        related_actor: str = "",
    ) -> Optional[Dict[str, Any]]:
        """便捷发布 Growth 事件。"""
        if not self.personality_event_bus:
            return None
        event = self.personality_event_bus.publish_growth_event(
            event_type=event_type,
            source=source,
            payload=payload,
            related_ids=related_ids,
            severity=severity,
            actor=actor,
            related_actor=related_actor,
        )
        return event.to_dict()

    def publish_reflection_event(
        self,
        event_type: str,
        source: str,
        payload: Optional[Dict[str, Any]] = None,
        related_ids: Optional[List[str]] = None,
        severity: str = "info",
        actor: str = "",
    ) -> Optional[Dict[str, Any]]:
        """便捷发布 Reflection 事件。"""
        if not self.personality_event_bus:
            return None
        event = self.personality_event_bus.publish_reflection_event(
            event_type=event_type,
            source=source,
            payload=payload,
            related_ids=related_ids,
            severity=severity,
            actor=actor,
        )
        return event.to_dict()

    def publish_identity_event(
        self,
        event_type: str,
        source: str,
        payload: Optional[Dict[str, Any]] = None,
        related_ids: Optional[List[str]] = None,
        severity: str = "info",
        actor: str = "",
    ) -> Optional[Dict[str, Any]]:
        """便捷发布 Identity 事件。"""
        if not self.personality_event_bus:
            return None
        event = self.personality_event_bus.publish_identity_event(
            event_type=event_type,
            source=source,
            payload=payload,
            related_ids=related_ids,
            severity=severity,
            actor=actor,
        )
        return event.to_dict()

    def publish_relationship_event(
        self,
        event_type: str,
        source: str,
        payload: Optional[Dict[str, Any]] = None,
        related_ids: Optional[List[str]] = None,
        severity: str = "info",
        actor: str = "",
    ) -> Optional[Dict[str, Any]]:
        """便捷发布 Relationship 事件。"""
        if not self.personality_event_bus:
            return None
        event = self.personality_event_bus.publish_relationship_event(
            event_type=event_type,
            source=source,
            payload=payload,
            related_ids=related_ids,
            severity=severity,
            actor=actor,
        )
        return event.to_dict()

    def subscribe_personality_event(
        self,
        handler,
        category: Optional[str] = None,
        event_types: Optional[List[str]] = None,
        handler_name: str = "",
    ) -> Optional[str]:
        """订阅人格事件。返回 subscriber_id，未启用时返回 None。"""
        if not self.personality_event_bus:
            return None
        return self.personality_event_bus.subscribe(
            handler=handler,
            category=category,
            event_types=event_types,
            handler_name=handler_name,
        )

    def unsubscribe_personality_event(self, subscriber_id: str) -> bool:
        """取消订阅人格事件。"""
        if not self.personality_event_bus:
            return False
        return self.personality_event_bus.unsubscribe(subscriber_id)

    def get_personality_event_history(
        self,
        limit: int = 100,
        offset: int = 0,
        categories: Optional[List[str]] = None,
        event_types: Optional[List[str]] = None,
        sources: Optional[List[str]] = None,
        severities: Optional[List[str]] = None,
        related_id: Optional[str] = None,
        actor: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """查询人格事件历史（支持过滤）。"""
        if not self.personality_event_bus:
            return []
        event_filter = None
        if any([categories, event_types, sources, severities, related_id, actor]):
            event_filter = EventFilter(
                categories=categories,
                event_types=event_types,
                sources=sources,
                severities=severities,
                related_id=related_id,
                actor=actor,
            )
        events = self.personality_event_bus.get_history(
            limit=limit,
            offset=offset,
            event_filter=event_filter,
        )
        return [e.to_dict() for e in events]

    def get_personality_event(self, event_id: str) -> Optional[Dict[str, Any]]:
        """按 ID 查询单个人格事件。"""
        if not self.personality_event_bus:
            return None
        event = self.personality_event_bus.get_event(event_id)
        return event.to_dict() if event else None

    def get_personality_event_bus_snapshot(self) -> Optional[Dict[str, Any]]:
        """获取人格事件总线快照（统计/审计）。"""
        if not self.personality_event_bus:
            return None
        return self.personality_event_bus.snapshot().to_dict()

    def get_personality_event_subscribers(self) -> List[Dict[str, Any]]:
        """获取所有人格事件订阅者。"""
        if not self.personality_event_bus:
            return []
        return self.personality_event_bus.get_subscribers()

    def clear_personality_event_history(self) -> int:
        """清空人格事件历史，返回清除数量。"""
        if not self.personality_event_bus:
            return 0
        return self.personality_event_bus.clear_history()

    def save_personality_event_history(self) -> bool:
        """显式保存人格事件历史。"""
        if not self.personality_event_bus:
            return False
        return self.personality_event_bus.save_history()

    def replay_personality_event_history(
        self,
        handler,
        categories: Optional[List[str]] = None,
        event_types: Optional[List[str]] = None,
        limit: int = 0,
    ) -> int:
        """重放人格事件历史给指定处理器，返回重放数量。"""
        if not self.personality_event_bus:
            return 0
        event_filter = None
        if categories or event_types:
            event_filter = EventFilter(
                categories=categories,
                event_types=event_types,
            )
        return self.personality_event_bus.replay_history(
            handler=handler,
            event_filter=event_filter,
            limit=limit,
        )
