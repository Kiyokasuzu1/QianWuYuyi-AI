# -*- coding: utf-8 -*-
"""
src/orchestrator_runtime_bridge.py

Phase 3.8.5: Orchestrator ↔ RuntimeCore 桥接

职责:
- 让 Orchestrator.process() 优先走 RuntimeCore.process() (Phase 3.7.3+ 13-阶段)
- RuntimeCore 失败时降级到 legacy `engine.generate()` 路径
- 保持 Orchestrator 既有行为兼容,所有现有调用代码无需修改

约束:
- 不修改 src/memory / src/emotion / src/growth / src/personality 核心模块
- 不修改 src/contracts/*
- 不修改 Orchestrator.process() 原签名 (user_message: str) -> str
- 独立于 src/runtime/runtime_bridge.py,避免耦合

使用:
    bridge = OrchestratorRuntimeBridge(orchestrator)
    reply = bridge.handle_message("hi")
    # 优先 RuntimeCore.process() → final_reply
    # Runtime 失败 → legacy_generate() 兜底
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class OrchestratorRuntimeBridge:
    """Orchestrator 与 RuntimeCore 的桥接（Phase 3.8.5 / v1.0）。

    设计:
    - 不持有 Orchestrator 的所有子系统（避免重复初始化）;
      启动时让 Orchestrator 把 self.engine / self.personality_resolver 暴露给本类
    - handle_message() 走 RuntimeCore.process(),失败 fallback 到 legacy
    """

    def __init__(
        self,
        orchestrator: Any,
        runtime_core: Optional[Any] = None,
        response_guard_chain: Optional[Any] = None,
    ) -> None:
        self._orch = orchestrator
        self._runtime = runtime_core
        self._guard_chain = response_guard_chain
        # 状态统计
        self._runtime_call_count = 0
        self._legacy_call_count = 0
        self._last_runtime_error: Optional[str] = None
        self._last_legacy_reason: Optional[str] = None
        self._last_ctx: Optional[Any] = None
        self._last_reply_source: Optional[str] = None  # "runtime" / "legacy"

    # --------------------------------------------------------
    # 注入 / 配置
    # --------------------------------------------------------
    def set_runtime_core(self, runtime_core: Any) -> None:
        """运行时注入 RuntimeCore（覆盖 __init__ 传入值）。"""
        self._runtime = runtime_core

    def set_guard_chain(self, guard_chain: Any) -> None:
        self._guard_chain = guard_chain

    # --------------------------------------------------------
    # 主入口
    # --------------------------------------------------------
    def handle_message(self, user_message: str) -> str:
        """处理一条用户消息,优先 RuntimeCore,失败 fallback。

        流程:
        1) 尝试 RuntimeCore.process(event)
           - 成功 → 读 ctx._final_reply
           - 失败 / 无 final_reply → 走 legacy
        2) legacy 路径:直接调 orchestrator.engine.generate(...)
        """
        # 1) 尝试 Runtime
        if self._runtime is not None:
            reply = self._try_runtime(user_message)
            if reply is not None:
                self._runtime_call_count += 1
                self._last_reply_source = "runtime"
                return reply
        # 2) legacy fallback
        self._last_legacy_reason = (
            self._last_runtime_error or "no_runtime_core"
        )
        self._legacy_call_count += 1
        self._last_reply_source = "legacy"
        return self._legacy_generate(user_message)

    # --------------------------------------------------------
    # 内部: Runtime 路径
    # --------------------------------------------------------
    def _try_runtime(self, user_message: str) -> Optional[str]:
        try:
            from src.runtime.events import Event

            event = Event(
                type="user_input",
                source="user",
                payload={"text": user_message, "content": user_message},
            )
            ctx = self._runtime.process(event)
            self._last_ctx = ctx
            self._last_runtime_error = None
            # final_reply 可能为 None / 空 → 视为失败
            final = getattr(ctx, "_final_reply", None)
            if final and isinstance(final, str) and final.strip():
                return final
            self._last_runtime_error = "empty_final_reply"
            return None
        except Exception as exc:  # noqa: BLE001
            self._last_runtime_error = repr(exc)
            logger.warning(
                "[OrchestratorRuntimeBridge] Runtime 路径失败: %s, fallback legacy",
                exc,
            )
            return None

    # --------------------------------------------------------
    # 内部: Legacy 路径（直接调 orchestrator.engine.generate）
    # --------------------------------------------------------
    def _legacy_generate(self, user_message: str) -> str:
        """Legacy fallback:直接走 Orchestrator.engine.generate(...)。"""
        orch = self._orch
        engine = getattr(orch, "engine", None)
        if engine is None:
            return "抱歉,我遇到了一些问题,请稍后再试。"
        # 复用 Orchestrator 已有的 personality / self_model 上下文抽取
        try:
            personality_context = (
                self._extract_legacy_personality(orch)
            )
            emotion_ctx = self._extract_legacy_emotion(orch)
            relationship_ctx = self._extract_legacy_relationship(orch)
            self_model_ctx = (
                orch.get_self_model_context()
                if hasattr(orch, "get_self_model_context")
                else None
            )
            history = getattr(orch, "history", [])
            chat_memories = self._extract_legacy_chat_memories(orch, user_message)
            reply = engine.generate(
                user_message=user_message,
                history=history,
                chat_memories=chat_memories,
                life_events=[],
                personality_context=personality_context,
                resolved_behavior=None,
                self_model_context=self_model_ctx,
                emotion_context=emotion_ctx,
                relationship_context=relationship_ctx,
                context_prompt_blocks=[],
            )
            return reply
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "[OrchestratorRuntimeBridge] legacy 路径失败: %s", exc
            )
            return "抱歉,我遇到了一些问题,请稍后再试。"

    # --------------------------------------------------------
    # Legacy 上下文抽取（不修改 Orchestrator 内部代码,只用 getattr 拉取）
    # --------------------------------------------------------
    @staticmethod
    def _extract_legacy_personality(orch: Any) -> Any:
        try:
            pr = getattr(orch, "personality_resolver", None)
            if pr is None:
                return None
            personality = pr.resolve()
            if hasattr(orch, "_get_personality_context"):
                return orch._get_personality_context(personality)
        except Exception:
            return None
        return None

    @staticmethod
    def _extract_legacy_emotion(orch: Any) -> Any:
        try:
            em = getattr(orch, "emotion_manager", None)
            if em is None:
                return {}
            # 简单契约:取 emotion_manager 的当前 state
            state = getattr(em, "get_state", None)
            if callable(state):
                return state() or {}
        except Exception:
            return {}
        return {}

    @staticmethod
    def _extract_legacy_relationship(orch: Any) -> Any:
        try:
            rel = getattr(orch, "relationship_state", None)
            if rel is not None and hasattr(rel, "get"):
                return rel.get() or {}
        except Exception:
            return {}
        return {}

    @staticmethod
    def _extract_legacy_chat_memories(orch: Any, user_message: str) -> list:
        """从 memory_store / vector_memory 抽取相关 chat_memories。"""
        try:
            memories = []
            ms = getattr(orch, "memory_store", None)
            if ms is not None and hasattr(ms, "load"):
                loaded = ms.load()
                if loaded:
                    memories.extend(loaded)
            vm = getattr(orch, "vector_memory", None)
            if vm is not None and hasattr(vm, "search"):
                results = vm.search(user_message, top_k=5) or []
                for r in results:
                    if r not in memories:
                        memories.append(r)
            return memories
        except Exception:
            return []

    # --------------------------------------------------------
    # 状态查询
    # --------------------------------------------------------
    @property
    def runtime_call_count(self) -> int:
        return self._runtime_call_count

    @property
    def legacy_call_count(self) -> int:
        return self._legacy_call_count

    @property
    def last_runtime_error(self) -> Optional[str]:
        return self._last_runtime_error

    @property
    def last_legacy_reason(self) -> Optional[str]:
        return self._last_legacy_reason

    @property
    def last_ctx(self) -> Optional[Any]:
        return self._last_ctx

    @property
    def last_reply_source(self) -> Optional[str]:
        return self._last_reply_source


__all__ = ["OrchestratorRuntimeBridge"]
